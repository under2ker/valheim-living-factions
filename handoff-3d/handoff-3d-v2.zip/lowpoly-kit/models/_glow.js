/*
 * Glow accents for axes: an emissive line along the blade, an emissive band on the handle and a
 * small emissive faction gem. Call it LAST in build() so earlier random draws keep their order.
 * Coordinates are given in the axe's own SVG units and converted with the axe's K.space helpers.
 */
(function (global) {
  'use strict';
  const K = LPK;
  const G = {};
  /** sp = { X, Y, S } from K.space(); o = accent config (see axe files). */
  G.accents = (sc, rnd, sp, o) => {
    const { X, Y, S } = sp;
    const tex = K.flat(rnd, o.color, 12, 8, 8);
    // blade: glowing line following each spine, sunk just under the face
    for (const spine of o.spines) {
      const path = spine.map(([x, y]) => [X(x), Y(y), o.bz]);
      sc.tube(sc.mesh(tex, .2, 8, o.name + '_blade_glow', 1), path, path.map(() => o.br), 5, 0, 0, rnd);
    }
    // handle: glowing band around the grip
    if (o.grip) {
      const [gy0, gy1] = [Y(o.grip[0]), Y(o.grip[1])];
      sc.prism(sc.mesh(tex, .2, 8, o.name + '_grip_glow', 1), 0, 0, Math.min(gy0, gy1), Math.max(gy0, gy1), o.gr, o.gr, 8);
    }
    // faction gem: small glowing octahedron on the socket / collar
    const gx = X(o.gem[0]), gy = Y(o.gem[1]), d = o.gs * 1.4;
    sc.lathe(sc.mesh(tex, .2, 8, o.name + '_gem', 1), [[0, gy - d], [o.gs, gy], [0, gy + d]], 4, gx, o.gz, Math.PI / 4);
  };
  global.LPG = G;
})(window);
