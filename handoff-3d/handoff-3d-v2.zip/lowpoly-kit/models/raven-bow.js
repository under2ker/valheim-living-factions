/*
 * Night Bow («Ночной Лук», Clan Raven). An asymmetric recurve of black-stained wood: the upper
 * limb is longer and its tip curls back like a wing, the lower limb is shorter and straighter.
 * Four black feathers are tied along the dark grey string. Silhouette cue: the hooked upper
 * wing-tip against a shorter lower limb, the feathers hanging off the string.
 */
(function (global) {
  'use strict';
  const { noiseFill, canvasTex } = LP;
  const K = LPK;

  // upper limb: long, wing-tip hooked back toward the string side
  const UPPER = [[0,0],[.12,.18],[.17,.46],[.10,.80],[.01,.98],[.04,1.08],[-.03,1.14]];
  // lower limb: shorter, straighter, its tip ends a little above the grip line
  const LOWER = [[0,0],[.12,-.16],[.15,-.42],[.09,-.78],[.02,-.98],[-.06,-1.05]];

  function cr(a, b, c, d, t) {
    const t2 = t*t, t3 = t2*t;
    return [0,1].map(i => .5*(2*b[i] + (-a[i]+c[i])*t + (2*a[i]-5*b[i]+4*c[i]-d[i])*t2 + (-a[i]+3*b[i]-3*c[i]+d[i])*t3));
  }
  function spline(ctrl, per) {
    const P = [ctrl[0], ...ctrl, ctrl[ctrl.length-1]], out = [];
    for (let s = 0; s < ctrl.length-1; s++) for (let j = 0; j < per; j++) out.push(cr(P[s], P[s+1], P[s+2], P[s+3], j/per));
    out.push(ctrl[ctrl.length-1]); return out;
  }
  const limb = (ctrl, per) => spline(ctrl, per).map(([x,y]) => [x,y,0]);
  const taper = (n, a, b) => Array.from({length: n}, (_, k) => a + (b-a)*Math.pow(k/(n-1), 1.1));

  function build() {
    const rnd = LP.rng(1302);
    const sc = new LP.Scene();

    const blackWood = K.wood(rnd, [42, 38, 40], { w: 24, h: 64, grain: 14, streaks: 18 });
    const riserTex = K.wood(rnd, [34, 30, 32], { w: 16, h: 32, grain: 12, streaks: 10 });
    const featherTex = canvasTex(8, 16, (x, w, h) => {
      noiseFill(x, w, h, [30, 30, 36], 18, rnd);
      x.fillStyle = 'rgba(120,124,140,.45)'; x.fillRect(3, 0, 1, h);     // central shaft line
    });
    const stringTex = K.wrap(rnd, [62, 62, 66], { w: 8, h: 16, pitch: 2, slope: .8, grain: 8 });
    const hornTex = K.flat(rnd, [40, 38, 42], 10, 8, 8);

    // asymmetric limbs
    const up = limb(UPPER, 4), low = limb(LOWER, 4);
    const limbs = sc.mesh(blackWood, .3, 10, 'limbs');
    sc.tube(limbs, up, taper(up.length, .03, .012), 6, 0, 0, rnd);
    sc.tube(limbs, low, taper(low.length, .028, .014), 6, 0, 0, rnd);

    // riser at the centre
    const riser = sc.mesh(riserTex, .15, 8, 'riser');
    sc.prism(riser, 0, 0, -.16, .16, .042, .038, 6);

    // string from the upper nock to the lower nock (dark grey)
    const yu = 1.14, yl = -1.05, xu = -.03, xl = -.06;
    const xAt = y => xu + (xl - xu) * (yu - y) / (yu - yl);
    const string = sc.mesh(stringTex, .15, 8, 'string');
    const sp = Array.from({length: 13}, (_, i) => { const y = yu + (yl - yu)*i/12; return [xAt(y), y, 0]; });
    sc.tube(string, sp, sp.map(() => .0055), 4, 0, 0, rnd);

    // black feather blades tied to the string, built flat, rotated a little, then placed
    const feathers = sc.mesh(featherTex, .25, 6, 'feathers');
    for (const y of [.9, .66, .42, .18]) {
      const ang = (rnd() - .5) * .4, sx = xAt(y);
      const m0 = sc.mark(feathers);
      sc.ribbon(feathers, [[0,0,0],[-.05,.005,.01],[-.11,.01,.02],[-.16,0,.03]], [.02,.05,.045,0], [0,1,0]);
      sc.transform(feathers, m0, p => { const q = K.rotZ(p, ang); return [q[0] + sx, q[1] + y, q[2]]; });
    }

    // dark horn nocks
    const nocks = sc.mesh(hornTex, .1, 6, 'nocks');
    for (const p of [up[up.length-1], low[low.length-1]]) sc.lathe(nocks, [[0,p[1]-.02],[.016,p[1]-.01],[.014,p[1]+.01],[0,p[1]+.02]], 5, p[0]);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['raven-bow'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -6, ry: 24, rx: 6, dist: 4.6, pivot: [0, -.045] },
      icon: { w: 512, h: 512, rz: -40, ry: 22, rx: 8, dist: 4.4, pivot: [0, -.045] },
    },
  };
})(window);
