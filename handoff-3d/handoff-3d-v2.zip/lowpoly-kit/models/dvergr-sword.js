/*
 * Рунный Меч (Dvergr Hold sword), detailed pass. Symmetric blade with glowing rune glyphs
 * set along both faces, flared copper crossguard with end caps, dark grip with a copper
 * wire wrap, copper pommel ringed with rune studs and holding a glowing crystal.
 */
(function (global) {
  'use strict';
  const K = LPK, B = LPB;

  function build() {
    const rnd = LP.rng(1105);
    const sc = new LP.Scene();

    const copperTex = K.metal(rnd, [170,108,64], { grain: 12, light: .14, w: 32, h: 128 });
    const darkTex = K.metal(rnd, [70,56,46], { grain: 12, w: 16, h: 16 });
    const runeTex = K.flat(rnd, [120,230,240], 14, 8, 8);
    const crystalTex = K.flat(rnd, [110,240,250], 16, 8, 8);
    const gripTex = K.wrap(rnd, [72,50,36], { pitch: 5, slope: .5, grain: 12, w: 32, h: 96 });
    const wireTex = K.flat(rnd, [214,150,92], 10, 8, 8);

    // symmetric double edge, widest near the guard
    const blade = [[-.1,.04],[-.11,.6],[-.05,1.05],[0,1.26],[.05,1.05],[.11,.6],[.1,.04]];
    B.blade(sc, sc.mesh(copperTex, .45, 16, 'blade'), blade, p => .015 + .004 * (1 - Math.abs(p[0]) / .11));

    // glowing rune channel plus a row of glyph stubs on both faces
    sc.box(sc.mesh(runeTex, .2, 8, 'runes', 1), -.012, .012, .12, 1.08, -.024, .024);
    const glyph = sc.mesh(runeTex, .2, 8, 'glyphs', 1);
    for (let i = 0; i < 6; i++) {
      const y = .2 + i * .14, s = i % 2 ? .03 : -.03;
      sc.box(glyph, s - .012, s + .012, y, y + .03, -.027, -.021);
      sc.box(glyph, s - .012, s + .012, y, y + .03, .021, .027);
    }

    // flared crossguard with copper end caps
    const guard = sc.mesh(copperTex, .4, 14, 'guard');
    sc.box(guard, -.2, .2, -.03, .03, -.035, .035);
    sc.box(guard, -.24, -.18, -.02, .06, -.03, .03);
    sc.box(guard, .18, .24, -.02, .06, -.03, .03);
    for (const x of [-.24, .24]) sc.lathe(guard, [[0,-.03],[.025,-.01],[.03,.02],[0,.04]], 6, x, 0);

    // dark grip, copper wire spiral, collar
    sc.prism(sc.mesh(gripTex, .05, 4, 'grip'), 0, 0, -.42, -.03, .034, .034, 8);
    const wire = []; for (let i = 0; i <= 56; i++) { const t = i / 56, a = t * Math.PI * 2 * 7; wire.push([Math.cos(a) * .037, -.41 + t * .36, Math.sin(a) * .037]); }
    sc.tube(sc.mesh(wireTex, .5, 18, 'copper_wire'), wire, wire.map(() => .0055), 4, 0, 0, rnd);
    sc.prism(sc.mesh(copperTex, .45, 14, 'collar'), 0, 0, -.45, -.42, .042, .042, 8);

    // round copper pommel with rune studs and a glowing crystal
    sc.lathe(sc.mesh(copperTex, .45, 14, 'pommel'), [[0,-.6],[.07,-.54],[.085,-.48],[.06,-.42],[.02,-.4]], 10);
    const studs = sc.mesh(darkTex, .2, 8, 'pommel_studs');
    for (let i = 0; i < 4; i++) {
      const a = i / 4 * Math.PI * 2;
      const m0 = sc.mark(studs);
      sc.lathe(studs, [[0,-.012],[.012,0],[0,.012]], 4);
      sc.transform(studs, m0, p => [p[0] + Math.cos(a) * .078, p[1] - .5, p[2] + Math.sin(a) * .078]);
    }
    sc.lathe(sc.mesh(crystalTex, .2, 8, 'pommel_crystal', 1), [[0,-.58],[.05,-.55],[.04,-.5],[0,-.47]], 6);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['dvergr-sword'] = { build, views: LPB.views };
})(window);
