/*
 * Blackgnaw («Черногрыз», Svartgnagr) — Fuling Horde. A raider's cleaver hammered out of
 * black metal: a heavy uneven slab with a sawtooth edge and a hook on top, riveted and
 * daubed with ochre war paint, lashed to a crooked branch with rope and rags, a string of
 * trophy teeth hanging below and a bone spike for a pommel.
 * Silhouette cue: a jagged block — brute mass, nothing symmetrical, nothing polished.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  function build() {
    const rnd = LP.rng(303);
    const sc = new LP.Scene();
    const { X, Y, S } = K.space(242, 380);

    // sawtooth cleaver with a hook on top
    const teeth = [[80,66],[54,82],[76,100],[50,120],[72,138],[47,158],[70,177],[46,197],[70,215],[50,235],[75,253],[56,272],[84,290]];
    const blade = [[226,70],[150,66],[118,56],[112,6],[94,22],[86,60], ...teeth, [104,306],[170,286],[226,254]];
    const BX0 = 46, BX1 = 226, BY0 = 6, BY1 = 306;

    const bladeTex = canvasTex(80, 128, (x, w, h) => {
      noiseFill(x, w, h, [44,48,44], 16, rnd);
      for (let i = 0; i < 200; i++) { x.fillStyle = rnd() < .5 ? 'rgba(0,0,0,.3)' : 'rgba(150,160,150,.12)';
        x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2 + Math.floor(rnd()*4), 2 + Math.floor(rnd()*3)); }
      for (let i = 0; i < 60; i++) { x.fillStyle = 'rgba(128,64,26,.55)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1 + Math.floor(rnd()*3), 1 + Math.floor(rnd()*2)); }
      const sx = v => (v - BX0) / (BX1 - BX0) * w, sy = v => (v - BY0) / (BY1 - BY0) * h;
      // ragged honed teeth: bright only in patches
      x.lineJoin = 'miter';
      x.beginPath(); teeth.forEach((p, i) => i ? x.lineTo(sx(p[0]), sy(p[1])) : x.moveTo(sx(p[0]), sy(p[1])));
      x.strokeStyle = '#7c8178'; x.lineWidth = 7; x.stroke(); x.strokeStyle = '#b9bdb2'; x.lineWidth = 2.5; x.stroke();
      for (let i = 0; i < 9; i++) { x.fillStyle = 'rgba(44,48,44,.9)'; const t = teeth[Math.floor(rnd()*teeth.length)]; x.fillRect(sx(t[0]) - 1, sy(t[1]) - 2, 3, 4); }
      // ochre war paint: three claw stripes and a crude eye
      x.strokeStyle = 'rgba(176,64,30,.9)'; x.lineWidth = 3; x.lineCap = 'round';
      for (let k = 0; k < 3; k++) { x.beginPath(); x.moveTo(sx(196 - k*16), sy(96)); x.lineTo(sx(176 - k*16), sy(200)); x.stroke(); }
      x.lineWidth = 2; x.beginPath(); x.arc(sx(116), sy(236), 6, 0, 6.283); x.stroke();
      x.fillStyle = 'rgba(176,64,30,.95)'; x.fillRect(Math.round(sx(116)) - 1, Math.round(sy(236)) - 1, 3, 3);
    });
    const ironTex = K.metal(rnd, [58,60,56], { grain: 22, rust: 40 });
    const barkTex = K.wood(rnd, [72,52,36], { w: 24, h: 96, grain: 26, streaks: 24, draw: (x, w, h) => {
      for (let i = 0; i < 12; i++) { x.fillStyle = 'rgba(28,18,10,.8)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2, 2); } } });
    const ragTex = K.wrap(rnd, [112,100,82], { pitch: 7, slope: .6, grain: 26, draw: (x, w, h) => {
      x.fillStyle = 'rgba(150,46,26,.7)'; x.fillRect(0, Math.floor(h*.4), w, 4); } });
    const ropeTex = K.wrap(rnd, [120,92,58], { w: 8, h: 32, pitch: 3, slope: .9 });
    const boneTex = K.flat(rnd, [222,210,184], 18, 16, 16);

    // crooked branch haft
    const haft = sc.mesh(barkTex, .05, 6, 'haft');
    const offs = [0, .022, -.012, .03, .004, -.018, .012, -.006, .01];
    const hp = offs.map((o, k) => [o, Y(706) + k/(offs.length - 1)*(Y(40) - Y(706)), o*.6]);
    sc.tube(haft, hp, hp.map((_, k) => .052 - .01*k/(hp.length - 1)), 6, .4, .16, rnd);
    sc.lathe(haft, [[.044,Y(42)],[.02,Y(28)],[0,Y(16)]], 6);                         // whittled stake top
    // rags
    const rag = sc.mesh(ragTex, .02, 4, 'rags');
    sc.tube(rag, [[.02,Y(662),.0],[.016,Y(612),.0],[.02,Y(560),.0]], [.066,.07,.064], 7, .5, .22, rnd);
    sc.ribbon(rag, [[.05,Y(570),.05],[.07,Y(600),.07],[.06,Y(640),.09],[.075,Y(680),.1]], [.05,.045,.04,.012], [1,0,0]);
    // rope lashing around the head: a helix
    const rope = sc.mesh(ropeTex, .05, 4, 'rope');
    const helix = []; for (let i = 0; i <= 90; i++) { const t = i/90, a = t*Math.PI*2*9; helix.push([Math.cos(a)*.064, Y(256) + t*(Y(66) - Y(256)), Math.sin(a)*.064]); }
    sc.tube(rope, helix, helix.map(() => .013), 4, 0, .1, rnd);

    // cleaver: uneven hammered thickness (wedge + hash jitter => irregular facets)
    const bx0 = X(BX0), bx1 = X(BX1), by0 = Y(BY1), by1 = Y(BY0);
    sc.extrude(sc.mesh(bladeTex, .35, 14, 'blade'), blade.map(p => S(p[0], p[1])),
      p => { const t = Math.max(0, Math.min(1, (p[0] - bx0) / (X(226) - bx0))); return .008 + .026*t + .004*K.hash2(p[0]*9, p[1]*9); },
      p => [(p[0] - bx0) / (bx1 - bx0), (p[1] - by0) / (by1 - by0)]);
    // glowing blade: an emissive skin a few percent thicker than the cleaver, same outline and profile
    // (fixed-colour texture, no rnd draws, so the rest of the build is unchanged)
    const emberBladeTex = LP.canvasTex(8, 8, (x, w, h) => { x.fillStyle = 'rgb(150,56,18)'; x.fillRect(0, 0, w, h); });
    // only the cutting edge glows: a thin glowing line along the sawtooth edge (the teeth that do the cutting)
    const cutEdge = teeth.map(p => [X(p[0]), Y(p[1]), .012]);
    sc.tube(sc.mesh(emberBladeTex, 0, 1, 'blade_glow', 1), cutEdge, cutEdge.map(() => .006), 5, 0, 0, rnd);
    const iron = sc.mesh(ironTex, .3, 12, 'rivets_collar');
    for (const [rx, ry] of [[150,110],[194,160],[150,214],[118,160]]) sc.box(iron, X(rx) - .022, X(rx) + .022, Y(ry) - .022, Y(ry) + .022, -.045, .045);
    sc.box(iron, X(226), X(252), Y(250), Y(74), -.04, .04);

    // trophy teeth on a cord
    const cord = sc.mesh(ropeTex, .05, 4, 'teeth_cord');
    const cp = [[X(236),Y(250),.06],[X(224),Y(290),.08],[X(208),Y(322),.085],[X(196),Y(346),.08]];
    sc.tube(cord, cp, cp.map(() => .006), 4, 0, 0, rnd);
    const bone = sc.mesh(boneTex, .3, 14, 'teeth_bone');
    [[.15,1.5],[.38,1.9],[.6,1.6],[.82,2.0],[1.0,1.7]].forEach(([t, s], i) => {
      const k = Math.min(cp.length - 2, Math.floor(t*(cp.length - 1) - 1e-6)), f = t*(cp.length - 1) - k;
      const c = cp[k].map((v, j) => v + (cp[k+1][j] - v)*f);
      const m0 = sc.mark(bone);
      sc.lathe(bone, [[0,-.075*s],[.012*s,-.05*s],[.018*s,-.012],[.014,0]], 5);
      sc.transform(bone, m0, p => { const q = K.rotZ(p, (i % 2 ? .25 : -.2)); return [q[0] + c[0], q[1] + c[1], q[2] + c[2]]; });
    });
    // bone spike pommel
    sc.lathe(bone, [[0,Y(800)],[.03,Y(752)],[.05,Y(716)],[.046,Y(700)]], 6);
    // glow accents (appended last so earlier random draws are unchanged)
    LPG.accents(sc, rnd, { X, Y, S }, {
      name: 'fuling', color: [246,150,64],
      spines: [], bz: 0.02, br: 0.006,
      grip: [170,160], gr: 0.066,
      gem: [239,160], gz: 0.044, gs: 0.024,
    });
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['fuling-blackgnaw'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -30, ry: 22, rx: 8, dist: 4.8, pivot: [.24, 0] },
      icon: { w: 512, h: 512, rz: -42, ry: 22, rx: 8, dist: 4.5, pivot: [.24, 0], offset: [-.18, -.1] },
    },
  };
})(window);
