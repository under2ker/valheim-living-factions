/*
 * Bark shield («Корковый Щит», Greydwarf Brood). Five thin slabs of bark stacked with small
 * offsets, bound by two vine helices round the edge, an amber resin blob at the centre and
 * roots poking out past the rim. Silhouette cue: light, layered, and a little alive.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  // revolve a [r, z] profile around the Z axis, centred at (cx, cy); jit adds rough radial noise
  function revolve(sc, m, prof, seg, jit = 0, rnd = null, cx = 0, cy = 0) {
    const G = prof.map(([r, z]) => {
      const row = [];
      for (let i = 0; i < seg; i++) {
        const a = i / seg * Math.PI * 2, j = jit ? 1 + jit * (rnd() * 2 - 1) : 1;
        row.push([cx + Math.cos(a) * r * j, cy + Math.sin(a) * r * j, z]);
      }
      return row;
    });
    for (let k = 0; k < G.length - 1; k++) for (let i = 0; i < seg; i++) {
      const i1 = (i + 1) % seg, v0 = k / (G.length - 1), v1 = (k + 1) / (G.length - 1);
      const u0 = i / seg, u1 = (i + 1) / seg;
      sc.quad(m, G[k][i], G[k][i1], G[k + 1][i1], G[k + 1][i], [u0, v0], [u1, v0], [u1, v1], [u0, v1]);
    }
  }

  function build() {
    const rnd = LP.rng(1206);
    const sc = new LP.Scene();

    const barkTex = K.wood(rnd, [136, 116, 84], { w: 32, h: 128, grain: 28, streaks: 40, draw: (x, w, h) => {
      for (let i = 0; i < 30; i++) { x.fillStyle = 'rgba(40,28,18,.6)'; x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 1, 3 + Math.floor(rnd() * 6)); }
      for (let i = 0; i < 16; i++) { x.fillStyle = 'rgba(190,176,140,.35)'; x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 2, 1); }
    } });
    const rootTex = K.wood(rnd, [90, 68, 46], { w: 16, h: 64, grain: 14, streaks: 10 });
    const vineTex = K.wrap(rnd, [96, 124, 66], { w: 8, h: 24, pitch: 3, slope: .8, grain: 16 });
    const vine2Tex = K.wrap(rnd, [84, 110, 58], { w: 8, h: 24, pitch: 4, slope: .8, grain: 16 });
    const ambTex = K.flat(rnd, [206, 134, 58], 18, 8, 8);

    // five stacked bark slabs, each a little off-centre and uneven at the rim
    const slabs = sc.mesh(barkTex, .15, 6, 'bark_slabs');
    for (let i = 0; i < 5; i++) {
      const cx = (rnd() - .5) * .05, cy = (rnd() - .5) * .05;
      const R = .68 + rnd() * .04 - (i % 2) * .02;
      const z0 = -.02 + i * .024, z1 = z0 + .04;
      revolve(sc, slabs, [[0, z1], [R, z1], [R, z0], [0, z0]], 9, .04, rnd, cx, cy);
    }

    // two vine helices wrapped round the stacked edge, crossing each other
    const vines = sc.mesh(vineTex, .05, 4, 'vine_wrap');
    const hA = [];
    for (let i = 0; i <= 25; i++) { const t = i / 25, a = t * Math.PI * 2 * 5; hA.push([Math.cos(a) * .72, Math.sin(a) * .72, -.03 + .14 * t]); }
    sc.tube(vines, hA, hA.map(() => .016), 3, 0, .15, rnd);

    const vines2 = sc.mesh(vine2Tex, .05, 4, 'vine_wrap_b');
    const hB = [];
    for (let i = 0; i <= 25; i++) { const t = i / 25, a = -t * Math.PI * 2 * 4 + 1.1; hB.push([Math.cos(a) * .71, Math.sin(a) * .71, .11 - .14 * t]); }
    sc.tube(vines2, hB, hB.map(() => .014), 3, 0, .15, rnd);

    // amber resin blob in the centre, the one glowing part
    const amber = sc.mesh(ambTex, .6, 30, 'amber_resin', 1);
    revolve(sc, amber, [[0, .08], [.06, .1], [.09, .12], [.06, .145], [0, .155]], 6);

    // roots pushing out past the rim
    const roots = sc.mesh(rootTex, .1, 5, 'roots');
    const rp = (r, an, z) => [Math.cos(an) * r, Math.sin(an) * r, z];
    for (const a of [.9, 2.5, 4.3]) {
      const path = [rp(.68, a, .05), rp(.76, a + .04, .02), rp(.86, a + .1, -.01), rp(.94, a + .2, -.05)];
      sc.tube(roots, path, [.03, .022, .014, .004], 4, 0, .12, rnd);
    }

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['greydwarf-shield'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -12, ry: 22, rx: 6, dist: 4.0, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -12, ry: 22, rx: 6, dist: 3.8, pivot: [0, 0] },
    },
  };
})(window);
