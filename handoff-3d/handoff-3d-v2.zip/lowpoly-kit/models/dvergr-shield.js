/*
 * Copper shield («Медный Щит», Dvergr Hold). A symmetric round face of thin hammered copper
 * with a raised bead rim, engraved rune bands across the field, a copper boss and a faceted
 * gem set in its centre. Silhouette cue: a clean disc with a bright bead and a jewel.
 */
(function (global) {
  'use strict';
  const K = LPK;

  // revolve a [r, z] profile around the Z axis, centred at (cx, cy)
  function revolve(sc, m, prof, seg, jit = 0, rnd = null, cx = 0, cy = 0) {
    const G = prof.map(([r, z]) => {
      const row = [];
      for (let i = 0; i < seg; i++) {
        const a = i / seg * Math.PI * 2, j = jit ? 1 + jit * (rnd() * 2 - 1) : 1;
        row.push([cx + Math.cos(a) * r * j, cy + Math.sin(a) * r * j, z]);
      }
      return row;
    });
    for (let k = 0; k < G.length - 1; k++) for (let i = 0; i < seg; i++) {
      const i1 = (i + 1) % seg, v0 = k / (G.length - 1), v1 = (k + 1) / (G.length - 1);
      const u0 = i / seg, u1 = (i + 1) / seg;
      sc.quad(m, G[k][i], G[k][i1], G[k + 1][i1], G[k + 1][i], [u0, v0], [u1, v0], [u1, v1], [u0, v1]);
    }
  }

  function build() {
    const rnd = LP.rng(1205);
    const sc = new LP.Scene();

    // engraved rune bands: rows of notched strokes across the copper (v runs centre -> rim)
    const copperTex = K.metal(rnd, [176, 112, 70], { grain: 16, light: .12, draw: (x, w, h) => {
      for (const y of [12, 27, 44, 56]) {
        x.fillStyle = 'rgba(70,34,20,.55)'; x.fillRect(0, y - 2, w, 1);
        for (let u = 2; u < w - 2; u += 4) {
          x.fillStyle = 'rgba(70,34,20,.8)';
          x.fillRect(u, y, 1, 4 + Math.floor(rnd() * 2));
          if (rnd() < .5) x.fillRect(u, y, 2, 1);
        }
      }
    } });
    const rimTex = K.metal(rnd, [186, 120, 74], { grain: 12, light: .14 });
    const bossTex = K.metal(rnd, [204, 140, 84], { grain: 10, light: .2 });
    const gemTex = K.flat(rnd, [72, 134, 126], 22, 8, 8);

    // thin copper face, slight dome
    const face = sc.mesh(copperTex, .55, 18, 'copper_face');
    revolve(sc, face, [[0, .03], [.3, .022], [.5, .014], [.6, .008], [.62, 0], [.6, -.012], [0, -.012]], 18);

    // raised bead rim
    const rim = sc.mesh(rimTex, .65, 24, 'copper_rim');
    revolve(sc, rim, [[.6, .01], [.64, .03], [.7, .036], [.73, .02], [.74, -.01], [.7, -.03], [.64, -.024], [.6, -.012]], 18);

    // ten rivets through the bead
    const rivets = sc.mesh(bossTex, .7, 20, 'copper_rivets');
    for (let i = 0; i < 10; i++) {
      const a = i / 10 * Math.PI * 2;
      revolve(sc, rivets, [[.022, .034], [.016, .05], [0, .054]], 4, 0, null, Math.cos(a) * .7, Math.sin(a) * .7);
    }

    // central copper boss
    const boss = sc.mesh(bossTex, .8, 30, 'copper_boss');
    revolve(sc, boss, [[.16, .02], [.13, .06], [.09, .1], [.05, .13], [0, .14]], 10);

    // faceted gem, the one glowing part
    const gem = sc.mesh(gemTex, .7, 40, 'gem', 1);
    revolve(sc, gem, [[0, .26], [.085, .17], [.09, .13], [.05, .11], [0, .1]], 6);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['dvergr-shield'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -12, ry: 22, rx: 6, dist: 3.9, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -12, ry: 22, rx: 6, dist: 3.7, pivot: [0, 0] },
    },
  };
})(window);
