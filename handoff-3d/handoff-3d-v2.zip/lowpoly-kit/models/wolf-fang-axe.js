/*
 * Wolf's Fang («Клык Волка», Ulfstann) — Wolf Clan relic axe for the Living Factions Valheim mod.
 *
 * Authoring space: the original 2D concept was drawn in an SVG of 420×720 units with the haft
 * centred on x=242 and the axe head at the top. Points are converted with
 *    X(sx) = (sx-242)/300      Y(sy) = -(sy-380)/300
 * so 300 SVG units ≈ 1 model unit, +Y is up and the haft lies on the Y axis.
 * Total length ≈ 2.1 units (scale it in the game to the vanilla axe's length).
 *
 * Determinism: ONE seeded RNG drives every texture and the fur jitter, in a fixed order.
 * Changing the order of calls changes the look — append new random work at the end.
 */
(function (global) {
  'use strict';
  const { bez, canvasTex, noiseFill } = LP;

  function build() {
    const rnd = LP.rng(7);
    const sc = new LP.Scene();
    const X = v => (v - 242) / 300, Y = v => -(v - 380) / 300;
    const S = (x, y) => [X(x), Y(y)];

    // ------------------------------------------------ outlines (SVG units)
    const bladeSvg = [[226,92],[150,104],
      ...bez([150,104],[118,96],[92,76],[64,46],3),      // top horn
      ...bez([64,46],[34,98],[26,168],[34,226],4),       // cutting edge, upper half
      ...bez([34,226],[42,286],[66,340],[100,382],4),    // cutting edge, lower half (beard)
      ...bez([100,382],[118,340],[140,288],[168,246],3), // beard inner curve
      ...bez([168,246],[190,220],[210,210],[226,206],2)];
    const pollSvg = [[264,110],[300,98],[314,120],[302,150],[300,176],[264,186]];
    const BX0 = 26, BX1 = 226, BY0 = 46, BY1 = 382;      // blade bbox => blade texture covers exactly this

    // ------------------------------------------------ textures (order matters: shared RNG)
    const bladeTex = canvasTex(72, 120, (x, w, h) => {
      noiseFill(x, w, h, [104,111,118], 14, rnd);
      for (let i = 0; i < 220; i++) {                    // painterly blotches 2–4 px
        x.fillStyle = rnd() < .5 ? 'rgba(40,44,50,.18)' : 'rgba(170,178,186,.14)';
        x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2 + Math.floor(rnd()*3), 2 + Math.floor(rnd()*3));
      }
      const sx = v => (v - BX0) / (BX1 - BX0) * w, sy = v => (v - BY0) / (BY1 - BY0) * h;
      x.fillStyle = 'rgba(30,32,36,.45)'; x.fillRect(sx(170), 0, w, h);          // forge scale near the socket
      for (let i = 0; i < 40; i++) { x.fillStyle = `rgba(20,22,25,${.25 + rnd()*.3})`; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1, 1); }
      x.strokeStyle = 'rgba(170,178,186,.35)'; x.lineWidth = 1;                   // scratches
      for (let i = 0; i < 10; i++) { const a = rnd()*w, b = rnd()*h; x.beginPath(); x.moveTo(a, b); x.lineTo(a + rnd()*8 - 4, b + rnd()*3); x.stroke(); }
      // honed edge: dark bevel line -> grey -> light -> almost white
      const edge = () => { x.beginPath(); x.moveTo(sx(64), sy(46));
        x.bezierCurveTo(sx(34), sy(98), sx(26), sy(168), sx(34), sy(226));
        x.bezierCurveTo(sx(42), sy(286), sx(66), sy(340), sx(100), sy(382)); };
      x.lineCap = 'round';
      edge(); x.strokeStyle = '#4b5157'; x.lineWidth = 19; x.stroke();
      edge(); x.strokeStyle = '#9aa3aa'; x.lineWidth = 16; x.stroke();
      edge(); x.strokeStyle = '#c3cad0'; x.lineWidth = 9;  x.stroke();
      edge(); x.strokeStyle = '#eef2f4'; x.lineWidth = 3;  x.stroke();
      // engraved wolf head: dark incision + bronze inlay
      const wolf = [[104,120],[118,146],[132,142],[146,146],[160,120],[164,160],[154,184],[136,206],[132,208],[128,206],[110,184],[100,160]];
      x.beginPath(); wolf.forEach((p, i) => i ? x.lineTo(sx(p[0]), sy(p[1])) : x.moveTo(sx(p[0]), sy(p[1]))); x.closePath();
      x.fillStyle = 'rgba(28,30,34,.55)'; x.fill(); x.strokeStyle = '#2a2d31'; x.lineWidth = 3; x.stroke();
      x.strokeStyle = '#c98a3c'; x.lineWidth = 1.4; x.stroke();
      x.fillStyle = '#e0a24c'; x.fillRect(Math.round(sx(118)), Math.round(sy(164)), 2, 1); x.fillRect(Math.round(sx(140)), Math.round(sy(164)), 2, 1);
      x.strokeStyle = '#c98a3c'; x.lineWidth = 1.2; x.beginPath(); x.moveTo(sx(126), sy(190)); x.lineTo(sx(132), sy(197)); x.lineTo(sx(138), sy(190)); x.stroke();
      // six runes stepping down the beard
      x.strokeStyle = '#b8792f'; x.lineWidth = 1;
      const runes = [[[0,0],[0,6],[3,3]],[[0,0],[0,6],[3,2],[0,3]],[[0,6],[0,0],[3,2]],[[0,0],[3,3],[0,6]],[[1.5,0],[1.5,6],[0,2],[1.5,0],[3,2]],[[0,6],[0,0],[3,1.5],[0,3],[3,4.5]]];
      let px = sx(150), py = sy(250);
      runes.forEach(r => { x.beginPath(); r.forEach((p, j) => j ? x.lineTo(px + p[0], py + p[1]) : x.moveTo(px + p[0], py + p[1])); x.stroke(); px -= 3.2; py += 6.4; });
    });
    const ironTex = canvasTex(32, 32, (x, w, h) => { noiseFill(x, w, h, [78,84,90], 30, rnd);
      x.fillStyle = 'rgba(20,22,25,.35)'; for (let i = 0; i < 30; i++) x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1, 1); });
    canvasTex(32, 32, (x, w, h) => noiseFill(x, w, h, [120,128,134], 30, rnd)); // unused (kept: preserves RNG sequence)
    const bronzeTex = canvasTex(16, 16, (x, w, h) => { noiseFill(x, w, h, [176,116,46], 34, rnd);
      x.fillStyle = 'rgba(255,210,130,.35)'; x.fillRect(0, 0, w, 3); x.fillStyle = 'rgba(60,30,8,.4)'; x.fillRect(0, h-3, w, 3); });
    const woodTex = canvasTex(24, 160, (x, w, h) => { noiseFill(x, w, h, [104,68,38], 18, rnd);
      for (let i = 0; i < 14; i++) { x.fillStyle = rnd() < .5 ? 'rgba(58,34,16,.55)' : 'rgba(150,104,60,.45)';
        const cx = Math.floor(rnd()*w); const y = Math.floor(rnd()*h); x.fillRect(cx, y, 1, 20 + Math.floor(rnd()*60)); }
      x.fillStyle = 'rgba(40,22,10,.8)'; x.fillRect(Math.floor(w*.3), Math.floor(h*.4), 2, 3); });           // knot
    const leatherTex = canvasTex(32, 64, (x, w, h) => { noiseFill(x, w, h, [74,48,32], 16, rnd);
      for (let k = -8; k < 16; k++) {                                     // diagonal wraps with shadow + highlight
        x.fillStyle = 'rgba(28,16,9,.85)'; for (let i = 0; i < w; i++) x.fillRect(i, Math.floor(k*6 + i*.35), 1, 1);
        x.fillStyle = 'rgba(130,92,64,.5)'; for (let i = 0; i < w; i++) x.fillRect(i, Math.floor(k*6 + i*.35) + 2, 1, 1); } });
    const furTex = canvasTex(32, 64, (x, w, h) => { const d = x.createImageData(w, h);
      for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
        const t = j / h; let g = 150 - 70*t + (rnd() - .5)*40;
        if ((i + Math.floor(j/6)) % 5 === 0) g -= 35;                     // strands
        if (t > .8) g = 40 + rnd()*20;                                     // dark tip
        if (t < .12) g = 190 + rnd()*30;                                   // pale root
        const o = (j*w + i)*4; d.data[o] = g*1.02; d.data[o+1] = g; d.data[o+2] = g*.94; d.data[o+3] = 255; }
      x.putImageData(d, 0, 0); });
    const cordTex = canvasTex(8, 32, (x, w, h) => { noiseFill(x, w, h, [62,40,24], 20, rnd);
      x.fillStyle = 'rgba(20,10,5,.7)'; for (let j = 0; j < h; j += 3) x.fillRect(0, j, w, 1); });

    // ------------------------------------------------ geometry
    sc.prism(sc.mesh(woodTex, .08, 8, 'haft'), 0, 0, Y(668), Y(70), .040, .044, 7, .2, 1);
    sc.prism(sc.mesh(leatherTex, .05, 6, 'grip'), 0, 0, Y(626), Y(458), .050, .050, 7, .2, 2.4);
    const rings = sc.mesh(bronzeTex, .55, 24, 'grip_rings');
    sc.prism(rings, 0, 0, Y(634), Y(624), .057, .057, 7, .2); sc.prism(rings, 0, 0, Y(462), Y(452), .057, .057, 7, .2);
    const pom = sc.mesh(ironTex, .45, 18, 'pommel');
    sc.prism(pom, 0, 0, Y(690), Y(650), .056, .044, 6, 0); sc.prism(pom, 0, 0, Y(700), Y(690), .04, .056, 6, 0);

    // blade: wedge — thick (≈3 cm) at the socket, ≈3 mm at the edge
    const bx0 = X(BX0), bx1 = X(BX1), by0 = Y(BY1), by1 = Y(BY0);
    sc.extrude(sc.mesh(bladeTex, .75, 30, 'blade'), bladeSvg.map(p => S(p[0], p[1])),
      p => { const t = (p[0] - bx0) / (X(220) - bx0); return .0035 + .028 * Math.max(0, Math.min(1, t)) ** 1.4; },
      p => [(p[0] - bx0) / (bx1 - bx0), (p[1] - by0) / (by1 - by0)]);

    const sock = sc.mesh(ironTex, .5, 20, 'socket');
    sc.box(sock, X(218), X(266), Y(216), Y(80), -.048, .048);
    sc.extrude(sock, pollSvg.map(p => S(p[0], p[1])),
      p => .036 - .02 * Math.max(0, (p[0] - X(264)) / (X(314) - X(264))), p => [p[0]*3, p[1]*3]);
    const bands = sc.mesh(bronzeTex, .6, 24, 'socket_bands');
    sc.box(bands, X(212), X(272), Y(108), Y(94), -.054, .054); sc.box(bands, X(212), X(272), Y(202), Y(188), -.054, .054);
    sc.box(sc.mesh(bronzeTex, .7, 30, 'rivet'), X(236), X(248), Y(154), Y(142), -.054, .054);

    // cord + wolf tail
    sc.tube(sc.mesh(cordTex, .05, 4, 'cord'),
      [[X(232),Y(214),.05],[X(228),Y(240),.07],[X(222),Y(270),.075],[X(220),Y(296),.07]], [.008,.008,.008,.008], 5, 0, .2, rnd);
    const tailPath = [], tailR = [], N = 13;
    for (let k = 0; k <= N; k++) { const t = k / N;
      tailPath.push([X(220) - .06*t*t - .01*Math.sin(t*3), Y(292) - t*.52, .07 + .03*Math.sin(t*2.4)]);
      tailR.push(t < .08 ? .02 : Math.sin(Math.min(1, t*1.15) * Math.PI * .92) * .075 + .008); }
    tailR[N] = .004;
    sc.tube(sc.mesh(furTex, .03, 4, 'wolf_tail'), tailPath, tailR, 8, .25, .2, rnd);
    sc.prism(sc.mesh(bronzeTex, .6, 24, 'tail_binding'), X(220), .07, Y(306), Y(290), .026, .026, 6, 0);
    // glowing round plates on the grip, a glowing grip end, and glowing plates holding the blade top and bottom
    // (fixed-colour texture; appended at the end so the earlier random draws are unchanged)
    const wolfGlowTex = LP.canvasTex(8, 8, (x, w, h) => { x.fillStyle = 'rgb(40,150,240)'; x.fillRect(0, 0, w, h); });
    const wolfGlow = sc.mesh(wolfGlowTex, .2, 8, 'wolf_glow_parts', 1);
    for (const y of [600, 540, 480]) sc.prism(wolfGlow, 0, 0, Y(y + 9), Y(y), .058, .058, 7, .2);
    sc.lathe(wolfGlow, [[0, Y(652)], [.052, Y(646)], [0, Y(640)]], 7);
    sc.box(wolfGlow, X(212), X(272), Y(106), Y(96), -.058, .058);
    sc.box(wolfGlow, X(212), X(272), Y(200), Y(190), -.058, .058);
    // glow accents (appended last so earlier random draws are unchanged)
    LPG.accents(sc, rnd, { X, Y, S }, {
      name: 'wolf', color: [150,214,236],
      spines: [], bz: 0.012, br: 0.006,
      grip: null, gr: 0,
      gem: [242,171], gz: 0.05, gs: 0.027,
    });
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['wolf-fang-axe'] = {
    build,
    // Named camera presets used by tools/build_all.sh
    views: {
      hero: { w: 1400, h: 1400, rz: -32, ry: 28, rx: 8, dist: 4.5, pivot: [.24, 0] },
      icon: { w: 512,  h: 512,  rz: -42, ry: 24, rx: 8, dist: 4.3, pivot: [.24, 0], offset: [-.2, -.1] },
    },
  };
})(window);
