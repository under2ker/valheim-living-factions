/*
 * Корневая Дубина (Greydwarf Brood sword), detailed pass. Root-club with knots and bark
 * texture, a split head holding ten flint chips, vine leaves along the shaft, living vine
 * wrap, and an amber eye that glows at the butt.
 */
(function (global) {
  'use strict';
  const K = LPK, B = LPB;

  function build() {
    const rnd = LP.rng(1106);
    const sc = new LP.Scene();

    const woodTex = K.wood(rnd, [96,74,48], { w: 32, h: 128, grain: 20, streaks: 26 });
    const knotTex = K.wood(rnd, [72,54,36], { w: 16, h: 32, grain: 16, streaks: 6 });
    const flintTex = K.metal(rnd, [120,118,112], { grain: 18, w: 16, h: 16, dark: .2 });
    const vineTex = K.wrap(rnd, [72,104,52], { pitch: 4, slope: .8, grain: 16, w: 16, h: 48 });
    const leafTex = K.flat(rnd, [84,128,60], 14, 8, 8);
    const amberTex = K.flat(rnd, [236,170,60], 16, 8, 8);
    const vineGlowTex = K.flat(rnd, [128,246,120], 12, 8, 8);

    // shaft: tapers from the grip up into the head, with a bark-ridged ribbon wrap
    sc.tube(sc.mesh(woodTex, .05, 4, 'shaft'), [[0,-.5,0],[.01,-.1,0],[.02,.4,0],[.01,.78,0]], [.04,.05,.06,.07], 8, .4, .03, rnd);
    // root knots stuck out of the shaft
    for (const [y, a] of [[-.2, .5], [.25, 2.4], [.55, 4.1]]) {
      const m0 = sc.mark(sc.mesh(knotTex, .05, 4, 'knot'));
      sc.lathe(sc.mesh(knotTex, .05, 4, 'knot'), [[0,-.04],[.035,-.02],[.04,.02],[0,.04]], 6);
      sc.transform(sc.mesh(knotTex, .05, 4, 'knot_tmp'), m0, p => p);
    }

    // knotted head with flat top
    sc.lathe(sc.mesh(woodTex, .05, 4, 'head'), [[.07,.72],[.11,.82],[.13,.98],[.12,1.1],[.07,1.2],[0,1.22]], 10);
    sc.lathe(sc.mesh(knotTex, .05, 4, 'head_knot'), [[.12,.9],[.15,.95],[.14,1.0],[.12,.98]], 6);

    // ten flint chips set around the head
    const flint = sc.mesh(flintTex, .3, 10, 'flint');
    for (let i = 0; i < 10; i++) {
      const a = i / 10 * Math.PI * 2 + .2, r = .13, lift = (i % 2) * .12;
      const m0 = sc.mark(flint);
      sc.lathe(flint, [[0,-.05],[.03,-.02],[.035,.02],[.02,.04],[0,.05]], 5);
      sc.transform(flint, m0, p => [p[0] + Math.cos(a) * r, p[1] + .9 + lift, p[2] + Math.sin(a) * r]);
    }

    // vine wrap round the grip (glowing green)
    const helix = [];
    for (let i = 0; i <= 90; i++) { const t = i / 90, a = t * Math.PI * 2 * 8; helix.push([Math.cos(a) * .052, -.46 + t * .4, Math.sin(a) * .052]); }
    sc.tube(sc.mesh(vineGlowTex, .2, 8, 'vine_glow', 1), helix, helix.map(() => .013), 4, 0, .1, rnd);

    // small leaves on the vine
    const leaves = sc.mesh(leafTex, .05, 4, 'leaves');
    for (let i = 0; i < 4; i++) {
      const y = -.4 + i * .1, a = i * 1.6;
      const m0 = sc.mark(leaves);
      sc.ribbon(leaves, [[0,0,0],[.04,0,0],[.07,.01,0]], [.02,.03,.01], [0,1,0]);
      sc.transform(leaves, m0, p => { const q = K.rotY(p, a); return [q[0] + Math.cos(a) * .06, q[1] + y, q[2] + Math.sin(a) * .06]; });
    }

    // amber eye at the butt (plain resin now; the vine carries the glow)
    sc.lathe(sc.mesh(amberTex, .2, 8, 'amber_eye', 0), [[0,-.6],[.04,-.55],[.05,-.5],[.03,-.46],[0,-.45]], 8);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['greydwarf-sword'] = { build, views: LPB.views };
})(window);
