/*
 * Рогатый Клинок (Clan Stag sword), detailed pass. Broad blade with an engraved hunting
 * scene texture, bronze ricasso with rings, crossguard forking into branched antler tines,
 * grip of antler segments separated by bronze spacers, pommel with a small antler crown.
 */
(function (global) {
  'use strict';
  const K = LPK, B = LPB;

    function build() {
    const rnd = LP.rng(1103);
    const sc = new LP.Scene();

    const bladeTex = K.metal(rnd, [136,140,132], { grain: 14, w: 32, h: 128, draw: (x, w, h) => {
      // engraved running-deer marks down the centre
      x.fillStyle = 'rgba(60,62,56,.6)';
      for (let i = 0; i < 4; i++) { const y = 20 + i * 26; x.fillRect(w / 2 - 6, y, 12, 2); x.fillRect(w / 2 - 6, y - 4, 2, 4); x.fillRect(w / 2 + 4, y - 4, 2, 4); }
    } });
    const bronzeTex = K.metal(rnd, [158,118,60], { grain: 12, light: .16, w: 32, h: 32 });
    const bronzeDark = K.metal(rnd, [110,80,40], { grain: 10, w: 16, h: 16 });
    const antlerTex = K.wood(rnd, [168,140,100], { w: 24, h: 96, grain: 14, streaks: 14 });

    // broad blade with wide shoulders and a rounded point (slimmed to 90% width, lengthened 10%)
    const blade = [[-0.135,0.04],[-0.144,0.876],[-0.108,1.151],[-0.036,1.316],[0.0,1.36],[0.036,1.316],[0.108,1.151],[0.144,0.876],[0.135,0.04]];
    B.blade(sc, sc.mesh(bladeTex, .35, 14, 'blade'), blade, p => .014 + .004 * (1 - Math.abs(p[0]) / .16));
    sc.box(sc.mesh(bronzeDark, .3, 10, 'fuller'), -.02, .02, .2, 1.0, -.016, .016);
    // glowing amber centre-line along the blade (emissive, sits proud of the faces)
    const amberGlow = K.flat(rnd, [240,190,100], 12, 8, 8);
    sc.box(sc.mesh(amberGlow, .2, 8, 'centre_glow', 1), -.01, .01, .2, 1.2, -.024, .024);

    // ricasso band with two bronze rings
    sc.box(sc.mesh(bronzeTex, .4, 14, 'ricasso'), -.155, .155, .02, .1, -.018, .018);
    sc.prism(sc.mesh(bronzeTex, .4, 14, 'ricasso_ring'), 0, 0, .1, .12, .16, .16, 8);

    // crossguard: two antler tines, each with a secondary branch
    const tines = sc.mesh(antlerTex, .1, 6, 'antler_guard');
    sc.tube(tines, [[-.02,-.01,0],[-.12,.04,0],[-.2,.16,0],[-.24,.26,0]], [.03,.024,.016,.008], 5, 0, .02, rnd);
    sc.tube(tines, [[.02,-.01,0],[.12,.04,0],[.2,.16,0],[.24,.26,0]], [.03,.024,.016,.008], 5, 0, .02, rnd);
    sc.tube(tines, [[-.13,.04,0],[-.16,.12,.02],[-.14,.2,.03]], [.018,.012,.006], 4, 0, .01, rnd);
    sc.tube(tines, [[.13,.04,0],[.16,.12,-.02],[.14,.2,-.03]], [.018,.012,.006], 4, 0, .01, rnd);
    sc.box(sc.mesh(bronzeTex, .4, 14, 'guard_core'), -.04, .04, -.04, .02, -.03, .03);

    // grip: antler segments with bronze spacers
    sc.prism(sc.mesh(antlerTex, .1, 6, 'antler_grip'), 0, 0, -.45, -.04, .038, .036, 8);
    for (const [y0, y1] of [[-.25,-.23],[-.1,-.08],[-.36,-.34]]) sc.prism(sc.mesh(bronzeTex, .4, 14, 'grip_rings'), 0, 0, y0, y1, .043, .043, 8);

    // pommel: bronze ring with a small antler crown
    sc.lathe(sc.mesh(bronzeTex, .4, 14, 'pommel'), [[0,-.58],[.07,-.52],[.085,-.47],[.05,-.44],[.02,-.43]], 8);
    const crown = [[-.04,-.46,0],[-.06,-.52,.01],[-.1,-.56,.02]];
    sc.tube(sc.mesh(antlerTex, .1, 6, 'crown'), crown, [.012,.01,.006], 4, 0, 0, rnd);
    sc.tube(sc.mesh(antlerTex, .1, 6, 'crown2'), [[.04,-.46,0],[.06,-.52,-.01],[.1,-.56,-.02]], [.012,.01,.006], 4, 0, 0, rnd);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['stag-sword'] = { build, views: LPB.views };
})(window);
