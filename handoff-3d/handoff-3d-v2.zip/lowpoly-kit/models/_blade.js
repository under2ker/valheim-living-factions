/*
 * Small helpers for blade-type items (swords). Model units: handle on the Y axis,
 * guard at y = 0, blade pointing up (+Y). Loaded before the sword models.
 */
(function (global) {
  'use strict';
  const L = {};
  /** Bounding box of a 2D outline. */
  L.bbox = (pts) => {
    let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
    for (const p of pts) { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); }
    return { x0, x1, y0, y1 };
  };
  /** Extrude a blade outline; th(p) is the half thickness at point p. UVs are the outline's bbox. */
  L.blade = (sc, mesh, pts, th) => {
    const b = L.bbox(pts);
    return sc.extrude(mesh, pts, th, p => [(p[0] - b.x0) / ((b.x1 - b.x0) || 1), (p[1] - b.y0) / ((b.y1 - b.y0) || 1)]);
  };
  /** Standard view presets for swords. */
  L.views = {
    hero: { w: 1400, h: 1400, rz: -32, ry: 22, rx: 8, dist: 6.8, pivot: [0, .4] },
    icon: { w: 512, h: 512, rz: -40, ry: 22, rx: 8, dist: 6.2, pivot: [0, .4] },
  };
  global.LPB = L;
})(window);
