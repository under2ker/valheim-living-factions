/*
 * Raven shield («Вороний Щит», Clan Raven). A tall kite of black-stained wood with a black
 * leather facing, a dark steel boss and a fan of raven feathers along the top edge.
 * Silhouette cue: a long pointed kite crowned with a feathered arc.
 */
(function (global) {
  'use strict';
  const { bez } = LP;
  const K = LPK;

  // revolve a [r, z] profile around the Z axis, centred at (cx, cy)
  function revolve(sc, m, prof, seg, jit = 0, rnd = null, cx = 0, cy = 0) {
    const G = prof.map(([r, z]) => {
      const row = [];
      for (let i = 0; i < seg; i++) {
        const a = i / seg * Math.PI * 2, j = jit ? 1 + jit * (rnd() * 2 - 1) : 1;
        row.push([cx + Math.cos(a) * r * j, cy + Math.sin(a) * r * j, z]);
      }
      return row;
    });
    for (let k = 0; k < G.length - 1; k++) for (let i = 0; i < seg; i++) {
      const i1 = (i + 1) % seg, v0 = k / (G.length - 1), v1 = (k + 1) / (G.length - 1);
      const u0 = i / seg, u1 = (i + 1) / seg;
      sc.quad(m, G[k][i], G[k][i1], G[k + 1][i1], G[k + 1][i], [u0, v0], [u1, v0], [u1, v1], [u0, v1]);
    }
  }

  function build() {
    const rnd = LP.rng(1202);
    const sc = new LP.Scene();

    const woodTex = K.wood(rnd, [44, 38, 36], { w: 24, h: 96, grain: 14, streaks: 18 });
    const leatherTex = K.wrap(rnd, [52, 48, 56], { w: 24, h: 48, pitch: 5, slope: .3, grain: 14 });
    const steelTex = K.metal(rnd, [58, 62, 72], { grain: 12, light: .14 });
    const featherTex = K.wrap(rnd, [40, 42, 56], { w: 12, h: 32, pitch: 3, slope: .6, grain: 16, draw: (x, w, h) => {
      x.fillStyle = 'rgba(90,110,150,.35)';
      for (let i = 0; i < 12; i++) x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 1, 3);
    } });
    const quillTex = K.flat(rnd, [150, 140, 120], 10, 8, 8);

    // kite outline: flat top, straight-ish sides, point at the bottom
    const top = [[-.34, .6], [-.18, .66], [0, .68], [.18, .66], [.34, .6]];
    const rs1 = bez([.34, .6], [.42, .5], [.42, .28], [.36, .12], 4);
    const rs2 = bez([.36, .12], [.3, -.2], [.14, -.56], [0, -.8], 4);
    const R = [...rs1, ...rs2];
    const L = R.slice(0, -1).reverse().map(p => [-p[0], p[1]]);
    const poly = [...top, ...R, ...L];

    // black-stained wood slab
    const wood = sc.mesh(woodTex, .15, 8, 'kite_wood');
    sc.extrude(wood, poly, () => .03, p => [(p[0] + .45) / .9, (p[1] + .85) / 1.55]);

    // black leather facing, inset so the wood shows as a dark border
    const inset = poly.map(p => [p[0] * .84, p[1] * .84 - .02]);
    const leather = sc.mesh(leatherTex, .25, 12, 'black_leather');
    sc.extrude(leather, inset, () => .04, p => [(p[0] + .4) / .8, (p[1] + .7) / 1.4]);

    // steel studs along the leather border
    const rivets = sc.mesh(steelTex, .7, 30, 'steel_rivets');
    for (let k = 0; k < inset.length; k += 4) revolve(sc, rivets, [[.018, .04], [.013, .05], [0, .054]], 4, 0, null, inset[k][0], inset[k][1]);

    // dark steel boss
    const boss = sc.mesh(steelTex, .7, 40, 'steel_boss');
    revolve(sc, boss, [[.13, .035], [.1, .07], [.06, .095], [.03, .108], [0, .112]], 9, 0, null, 0, .05);

    // seven feathers fanned along the top edge, each leaning back into the shield
    const feathers = sc.mesh(featherTex, .35, 24, 'raven_feathers');
    const quills = sc.mesh(quillTex, .1, 6, 'raven_quills');
    const FP = [[0, 0, 0], [.012, .1, 0], [.03, .2, 0], [.04, .28, 0], [.03, .34, 0]];
    const FW = [.03, .07, .085, .06, .005];
    const QP = [[0, 0, 0], [0, .15, 0], [.02, .3, 0]];
    for (let i = 0; i < 7; i++) {
      const bx = -.3 + i * .1, by = .66 - .4 * bx * bx, bz = .03, th = (i - 3) * .24;
      const fm = sc.mark(feathers), qm = sc.mark(quills);
      sc.ribbon(feathers, FP, FW, [1, 0, 0]);
      sc.tube(quills, QP, [.012, .01, .004], 3, 0, 0, rnd);
      const place = p => { const q = K.rotZ(p, th); return [q[0] + bx, q[1] + by, bz + p[2] - .18 * p[1]]; };
      sc.transform(feathers, fm, place);
      sc.transform(quills, qm, place);
    }

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['raven-shield'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -8, ry: 22, rx: 6, dist: 4.4, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -8, ry: 22, rx: 6, dist: 4.2, pivot: [0, 0] },
    },
  };
})(window);
