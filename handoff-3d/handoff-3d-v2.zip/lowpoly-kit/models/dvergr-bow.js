/*
 * Rune Bow («Рунный Лук», Dvergr Hold). A symmetric, heavy bow of dark wood: copper bands
 * wrap both limbs, copper caps close the tips, and a riser with a row of rune bands sits at
 * the grip, where a small pale crystal glows. Silhouette cue: a stiff, even ")" with the
 * copper rings catching the light along each limb.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  // symmetric heavy limb: full belly, straight to the nock
  const UPPER = [[0,0],[.12,.16],[.16,.44],[.10,.78],[.0,1.0],[-.05,1.1]];

  function cr(a, b, c, d, t) {
    const t2 = t*t, t3 = t2*t;
    return [0,1].map(i => .5*(2*b[i] + (-a[i]+c[i])*t + (2*a[i]-5*b[i]+4*c[i]-d[i])*t2 + (-a[i]+3*b[i]-3*c[i]+d[i])*t3));
  }
  function spline(ctrl, per) {
    const P = [ctrl[0], ...ctrl, ctrl[ctrl.length-1]], out = [];
    for (let s = 0; s < ctrl.length-1; s++) for (let j = 0; j < per; j++) out.push(cr(P[s], P[s+1], P[s+2], P[s+3], j/per));
    out.push(ctrl[ctrl.length-1]); return out;
  }
  const limb = (ctrl, per) => spline(ctrl, per).map(([x,y]) => [x,y,0]);
  const mirrorY = pts => pts.map(([x,y,z]) => [x,-y,z]);
  const taper = (n, a, b) => Array.from({length: n}, (_, k) => a + (b-a)*Math.pow(k/(n-1), 1.1));

  function build() {
    const rnd = LP.rng(1305);
    const sc = new LP.Scene();

    const darkWood = K.wood(rnd, [60, 46, 38], { w: 24, h: 64, grain: 14, streaks: 20 });
    const copperTex = K.metal(rnd, [170, 110, 70], { w: 16, h: 16, grain: 14, rust: 6, blotches: 16 });
    const runeTex = canvasTex(32, 48, (x, w, h) => {
      noiseFill(x, w, h, [52, 44, 40], 14, rnd);
      x.fillStyle = 'rgba(190,120,70,.85)';
      for (let j = 0; j < 4; j++) x.fillRect(0, 4 + j*12 + (j % 2)*2, w, 1);             // copper bands
      for (let i = 0; i < 5; i++) {                                                     // rune glyphs in a row
        const gx = 3 + i*6, gy = 20 + (i % 2);
        x.fillRect(gx, gy, 1, 8); x.fillRect(gx + 1, gy + (i % 2 ? 2 : 6), 2, 1); x.fillRect(gx + 2, gy + 4, 1, 1);
      }
    });
    const crystalTex = K.flat(rnd, [116, 176, 164], 20, 8, 8);
    const stringTex = K.wrap(rnd, [88, 84, 78], { w: 8, h: 16, pitch: 2, slope: .8, grain: 8 });

    // symmetric limbs, heavier at the grip
    const up = limb(UPPER, 4), low = mirrorY(up), n = up.length;
    const r = taper(n, .042, .02);
    const limbs = sc.mesh(darkWood, .3, 10, 'limbs');
    sc.tube(limbs, up, r, 6, 0, 0, rnd);
    sc.tube(limbs, low, r, 6, 0, 0, rnd);

    // copper bands: short tubes just wider than the limb at three points on each limb
    const bands = sc.mesh(copperTex, .45, 16, 'copper_bands');
    for (const L of [up, low]) for (const i of [4, 9, 15]) {
      sc.tube(bands, [L[i-1], L[i], L[i+1]], [r[i-1]+.006, r[i]+.006, r[i+1]+.006], 8, 0, 0, rnd);
    }

    // copper end caps
    const caps = sc.mesh(copperTex, .45, 16, 'copper_caps');
    for (const p of [up[n-1], low[n-1]]) sc.lathe(caps, [[0,p[1]-.03],[.026,p[1]-.02],[.028,p[1]],[.02,p[1]+.02],[0,p[1]+.03]], 6, p[0]);

    // riser with the rune row
    const riser = sc.mesh(runeTex, .2, 8, 'riser');
    sc.prism(riser, 0, 0, -.17, .17, .046, .046, 6);

    // glowing crystal on the grip, facing out from the belly side
    const crystal = sc.mesh(crystalTex, 0, 1, 'grip_crystal', 1);
    sc.lathe(crystal, [[0,-.07],[.03,-.03],[.04,0],[.03,.03],[0,.07]], 5, .07, 0);

    // string
    const string = sc.mesh(stringTex, .15, 8, 'string');
    const sp = Array.from({length: 13}, (_, i) => [-.05, 1.1 - 2.2*i/12, 0]);
    sc.tube(string, sp, sp.map(() => .0055), 4, 0, 0, rnd);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['dvergr-bow'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -6, ry: 24, rx: 6, dist: 4.6, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -40, ry: 22, rx: 8, dist: 4.4, pivot: [0, 0] },
    },
  };
})(window);
