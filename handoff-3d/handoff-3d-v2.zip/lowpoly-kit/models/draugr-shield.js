/*
 * Bone-plate shield («Щит Костяных Пластин», Draugr Court). Pale bone scales overlap in
 * staggered rows over a dark backing, an iron rim frames them, a crescent-moon iron boss sits
 * at the centre and bone charms dangle from cords at the bottom. Silhouette cue: a scaled,
 * armoured disc with a moon at its heart and charms rattling below.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  // revolve a [r, z] profile around the Z axis, centred at (cx, cy)
  function revolve(sc, m, prof, seg, jit = 0, rnd = null, cx = 0, cy = 0) {
    const G = prof.map(([r, z]) => {
      const row = [];
      for (let i = 0; i < seg; i++) {
        const a = i / seg * Math.PI * 2, j = jit ? 1 + jit * (rnd() * 2 - 1) : 1;
        row.push([cx + Math.cos(a) * r * j, cy + Math.sin(a) * r * j, z]);
      }
      return row;
    });
    for (let k = 0; k < G.length - 1; k++) for (let i = 0; i < seg; i++) {
      const i1 = (i + 1) % seg, v0 = k / (G.length - 1), v1 = (k + 1) / (G.length - 1);
      const u0 = i / seg, u1 = (i + 1) / seg;
      sc.quad(m, G[k][i], G[k][i1], G[k + 1][i1], G[k + 1][i], [u0, v0], [u1, v0], [u1, v1], [u0, v1]);
    }
  }

  // torus in the XY plane: ring radius R, tube radius r.
  function torus(sc, m, R, r, nM, nm) {
    const P = [];
    for (let j = 0; j < nM; j++) {
      const a = j / nM * Math.PI * 2, row = [];
      for (let i = 0; i < nm; i++) {
        const b = i / nm * Math.PI * 2, q = R + r * Math.cos(b);
        row.push([Math.cos(a) * q, Math.sin(a) * q, r * Math.sin(b)]);
      }
      P.push(row);
    }
    for (let j = 0; j < nM; j++) for (let i = 0; i < nm; i++) {
      const j1 = (j + 1) % nM, i1 = (i + 1) % nm;
      sc.quad(m, P[j][i], P[j][i1], P[j1][i1], P[j1][i], [j / nM, i / nm], [j / nM, (i + 1) / nm], [(j + 1) / nM, (i + 1) / nm], [(j + 1) / nM, i / nm]);
    }
  }

  function build() {
    const rnd = LP.rng(1207);
    const sc = new LP.Scene();

    const boneTex = canvasTex(32, 32, (x, w, h) => {
      noiseFill(x, w, h, [212, 202, 176], 16, rnd);
      for (let c = 0; c < 4; c++) {                                   // dark cracks
        let px = Math.floor(rnd() * w), py = Math.floor(rnd() * h);
        for (let s = 0; s < 4; s++) {
          x.fillStyle = 'rgba(70,56,44,.85)';
          x.fillRect(px, py, 1, 2);
          px += Math.floor(rnd() * 7) - 3; py += 2 + Math.floor(rnd() * 4);
        }
      }
    });
    const backTex = K.wrap(rnd, [58, 46, 40], { w: 24, h: 24, pitch: 5, slope: .3, grain: 14 });
    const ironTex = K.metal(rnd, [84, 80, 78], { grain: 16, rust: 30 });
    const cordTex = K.wrap(rnd, [70, 56, 42], { w: 8, h: 24, pitch: 3, slope: .8, grain: 14 });
    const charmTex = K.flat(rnd, [226, 214, 186], 14, 8, 8);

    // dark backing, so the gaps between scales read as shadow
    const back = sc.mesh(backTex, .05, 4, 'backing');
    revolve(sc, back, [[0, -.02], [.66, -.02], [.7, -.005], [.7, .005], [.66, .02], [0, .02]], 16);

    // eight bone plates in staggered rows, each lifted and tilted a little
    const plates = sc.mesh(boneTex, .3, 12, 'bone_plates');
    const outline = [[-.13, -.03], [-.08, -.14], [.02, -.17], [.12, -.1], [.14, .02], [.08, .13], [-.04, .16], [-.13, .08]];
    const ROWS = [[.44, [-.22, .22]], [.16, [-.44, 0, .44]], [-.12, [-.22, .22]], [-.4, [0]]];
    let row = 0;
    for (const [y, xs] of ROWS) {
      for (const x of xs) {
        const rot = (rnd() - .5) * .5, tilt = (rnd() - .5) * .3, lift = .04 + .012 * row;
        const m0 = sc.mark(plates);
        sc.extrude(plates, outline, () => .016, p => [(p[0] + .15) / .3, (p[1] + .18) / .36], lift);
        const c = Math.cos(tilt), s = Math.sin(tilt);
        sc.transform(plates, m0, p => {
          const q = K.rotZ(p, rot);
          return [q[0] + x, q[1] * c - q[2] * s + y, q[1] * s + q[2] * c];
        });
      }
      row++;
    }

    // iron rim
    const rim = sc.mesh(ironTex, .4, 14, 'iron_rim');
    torus(sc, rim, .7, .035, 16, 5);

    // crescent-moon boss: outer arc (r .17) minus an offset inner arc (r .15 at x .06)
    const moon = sc.mesh(ironTex, .6, 30, 'moon_boss');
    const moonPts = [];
    for (let i = 0; i <= 6; i++) {
      const a = (60.7 + i * 238.6 / 6) * Math.PI / 180;
      moonPts.push([Math.cos(a) * .17, Math.sin(a) * .17]);
    }
    for (let i = 1; i <= 5; i++) {
      const b = (279.3 - i * 198.6 / 6) * Math.PI / 180;
      moonPts.push([.06 + Math.cos(b) * .15, Math.sin(b) * .15]);
    }
    sc.extrude(moon, moonPts, () => .02, p => [(p[0] + .2) / .4, (p[1] + .2) / .4], .08);

    // two cords from the bottom rim, with bone charms
    const cords = sc.mesh(cordTex, .05, 4, 'cords');
    const charms = sc.mesh(charmTex, .3, 12, 'bone_charms');
    const cordA = [[-.1, -.68, .02], [-.16, -.8, .03], [-.24, -.9, .04], [-.22, -.98, .04]];
    const cordB = [[.1, -.68, .02], [.18, -.8, .03], [.27, -.88, .04]];
    sc.tube(cords, cordA, [.012, .01, .01, .008], 4, 0, .1, rnd);
    sc.tube(cords, cordB, [.012, .01, .008], 4, 0, .1, rnd);
    const tooth = [[-.03, 0], [.03, 0], [.025, -.05], [0, -.1], [-.025, -.05]];
    for (const [ox, oy] of [[-.22, -.98], [.27, -.88]]) {
      sc.extrude(charms, tooth.map(([tx, ty]) => [ox + tx, oy + ty]), () => .012, p => [p[0] * 5 + .5, p[1] * 5 + .5], .04);
    }
    revolve(sc, charms, [[0, .0], [.03, .02], [.035, .04], [.02, .06], [0, .07]], 5, 0, null, -.16, -.8);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['draugr-shield'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -12, ry: 22, rx: 6, dist: 4.3, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -12, ry: 22, rx: 6, dist: 4.1, pivot: [0, 0] },
    },
  };
})(window);
