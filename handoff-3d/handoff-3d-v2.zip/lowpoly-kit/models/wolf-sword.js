/*
 * Серый Клинок (Clan Wolf sword), detailed pass. Straight blade with a fuller and
 * bevelled edges, engraved wolf tracks on the steel, notched guard with ball tips and a
 * central diamond, studded grey leather grip, wolf-head pommel with snout and ears.
 */
(function (global) {
  'use strict';
  const K = LPK, B = LPB;

  function build() {
    const rnd = LP.rng(1101);
    const sc = new LP.Scene();

    const bladeTex = K.metal(rnd, [150,156,162], { grain: 14, w: 32, h: 128, dark: .14, light: .18, draw: (x, w, h) => {
      // engraved wolf tracks along the fuller
      x.fillStyle = 'rgba(40,44,50,.55)';
      for (let i = 0; i < 6; i++) {
        const y = 14 + i * 18;
        x.fillRect(w / 2 - 3, y, 2, 3); x.fillRect(w / 2 + 1, y + 4, 2, 3); x.fillRect(w / 2 - 4, y + 8, 2, 2);
      }
    } });
    const ironTex = K.metal(rnd, [70,74,78], { grain: 14, rust: 10, w: 32, h: 32 });
    const leatherTex = K.wrap(rnd, [96,92,86], { pitch: 5, slope: .4, grain: 14, w: 32, h: 96 });
    const studTex = K.flat(rnd, [186,190,194], 12, 8, 8);
    const pommelTex = K.metal(rnd, [84,88,92], { grain: 12, w: 32, h: 32 });
    const eyeTex = K.flat(rnd, [30,30,34], 6, 4, 4);

    // blade: fuller ridge, then bevelled edge plates slightly thinner than the spine
    const blade = [[-.105,.03],[-.11,1.05],[-.03,1.2],[0,1.27],[.03,1.2],[.11,1.05],[.105,.03]];
    B.blade(sc, sc.mesh(bladeTex, .4, 16, 'blade'), blade, p => .011 + .004 * (1 - Math.abs(p[0]) / .11));
    const edge = [[-.11,.06],[-.116,1.02],[-.04,1.18],[-.1,1.04]];
    B.blade(sc, sc.mesh(ironTex, .5, 20, 'bevel_left'), edge, p => .0045);
    B.blade(sc, sc.mesh(ironTex, .5, 20, 'bevel_right'), edge.map(p => [-p[0], p[1]]), p => .0045);
    // glowing rune-line down the centre of the blade (emissive, follows the fuller)
    const glowTex = K.flat(rnd, [150,214,236], 12, 8, 8);
    sc.box(sc.mesh(glowTex, .2, 8, 'fuller_glow', 1), -.012, .012, .08, 1.1, -.0135, .0135);

    // guard: long bar, notched tips with ball ends, diamond at the centre
    const guard = sc.mesh(ironTex, .3, 12, 'guard');
    sc.box(guard, -.22, .22, -.03, .04, -.035, .035);
    for (const x of [-.22, .22]) {
      sc.box(guard, x - .02, x + .02, -.05, -.02, -.03, .03);
      sc.lathe(guard, [[0,-.005],[.03,0],[.035,.02],[.03,.04],[0,.045]], 6, x, 0);
    }
    sc.lathe(sc.mesh(pommelTex, .4, 14, 'guard_diamond'), [[0,-.05],[.03,0],[0,.05],[-.03,0]], 4, 0, 0);

    // grip: studded leather with brass-look end collars
    sc.prism(sc.mesh(leatherTex, .05, 4, 'grip'), 0, 0, -.44, -.03, .036, .036, 8);
    const studs = sc.mesh(studTex, .4, 16, 'grip_studs');
    for (let i = 0; i < 4; i++) {
      const y = -.4 + i * .09, a = i * 1.3;
      const m0 = sc.mark(studs);
      sc.lathe(studs, [[0,-.008],[.01,0],[0,.008]], 4);
      sc.transform(studs, m0, p => [p[0] + Math.cos(a) * .038, p[1] + y, p[2] + Math.sin(a) * .038]);
    }
    sc.prism(sc.mesh(pommelTex, .35, 14, 'collar'), 0, 0, -.46, -.42, .042, .042, 8);

    // pommel: wolf head, snout, two ears, dark eyes
    sc.lathe(sc.mesh(pommelTex, .35, 14, 'pommel'), [[0,-.6],[.05,-.56],[.075,-.5],[.055,-.45],[.025,-.43]], 8);
    for (const s of [-1, 1]) sc.box(sc.mesh(pommelTex, .35, 14, 'pommel_ears'), s*.04 - .018, s*.04 + .018, -.5, -.44, -.02, .02);
    sc.box(sc.mesh(pommelTex, .35, 14, 'snout'), -.02, .02, -.56, -.5, .04, .07);
    sc.box(sc.mesh(eyeTex, .1, 4, 'eyes'), -.05, -.035, -.52, -.5, .05, .08);
    sc.box(sc.mesh(eyeTex, .1, 4, 'eyes2'), .035, .05, -.52, -.5, .05, .08);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['wolf-sword'] = { build, views: LPB.views };
})(window);
