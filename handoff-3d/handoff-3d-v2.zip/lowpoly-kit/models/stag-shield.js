/*
 * Stag-trail shield («Щит Оленьей Тропы», Clan Stag). A round board of tan deer-hide, dished
 * slightly, with a bronze trim ring, a bronze boss and two antler tines standing out of it.
 * Bronze coins are stitched around the rim. Silhouette cue: a round shield with antler tips
 * and a gold edge of coins, a merchant's rather than a warrior's shield.
 */
(function (global) {
  'use strict';
  const K = LPK;

  // revolve a [r, z] profile around the Z axis, centred at (cx, cy)
  function revolve(sc, m, prof, seg, jit = 0, rnd = null, cx = 0, cy = 0) {
    const G = prof.map(([r, z]) => {
      const row = [];
      for (let i = 0; i < seg; i++) {
        const a = i / seg * Math.PI * 2, j = jit ? 1 + jit * (rnd() * 2 - 1) : 1;
        row.push([cx + Math.cos(a) * r * j, cy + Math.sin(a) * r * j, z]);
      }
      return row;
    });
    for (let k = 0; k < G.length - 1; k++) for (let i = 0; i < seg; i++) {
      const i1 = (i + 1) % seg, v0 = k / (G.length - 1), v1 = (k + 1) / (G.length - 1);
      const u0 = i / seg, u1 = (i + 1) / seg;
      sc.quad(m, G[k][i], G[k][i1], G[k + 1][i1], G[k + 1][i], [u0, v0], [u1, v0], [u1, v1], [u0, v1]);
    }
  }

  function build() {
    const rnd = LP.rng(1203);
    const sc = new LP.Scene();

    const woodTex = K.wood(rnd, [150, 116, 76], { w: 24, h: 96, grain: 14, streaks: 14 });
    const hideTex = K.wrap(rnd, [184, 146, 98], { w: 32, h: 32, pitch: 8, slope: .25, grain: 22, draw: (x, w, h) => {
      // row of stitch dashes near the rim (v = 0 is the bottom row of the canvas)
      x.fillStyle = 'rgba(236,220,180,.7)';
      for (let u = 0; u < w; u += 4) x.fillRect(u, h - 3, 2, 1);
    } });
    const bronzeTex = K.metal(rnd, [168, 120, 58], { grain: 14, light: .18 });
    const antlerTex = K.wood(rnd, [206, 186, 150], { w: 16, h: 64, grain: 10, streaks: 8 });

    // wooden core, flat face
    const wood = sc.mesh(woodTex, .1, 6, 'wood_disc');
    revolve(sc, wood, [[0, -.03], [.5, -.03], [.66, -.02], [.7, -.008], [.7, .008], [.66, .02], [.5, .03], [0, .03]], 14);

    // deer hide, dished: the rim stands up, the centre sinks
    const hide = sc.mesh(hideTex, .15, 8, 'deer_hide');
    revolve(sc, hide, [[.7, 0], [.68, .03], [.6, .05], [.4, .046], [.2, .037], [0, .034]], 14);

    // bronze trim band over the hide edge
    const trim = sc.mesh(bronzeTex, .6, 24, 'bronze_trim');
    revolve(sc, trim, [[.64, 0], [.68, .03], [.72, .04], [.74, .02], [.72, -.01], [.66, -.01]], 14);

    // bronze boss
    const boss = sc.mesh(bronzeTex, .7, 30, 'bronze_boss');
    revolve(sc, boss, [[.16, .03], [.13, .07], [.08, .11], [.04, .13], [0, .14]], 10);

    // two antler tines rising from the boss
    const tines = sc.mesh(antlerTex, .1, 4, 'antler_tines');
    sc.tube(tines, [[0, 0, .12], [-.06, .07, .2], [-.13, .16, .22], [-.17, .26, .18]], [.034, .028, .02, .009], 5, .4, 0, rnd);
    sc.tube(tines, [[0, 0, .12], [.07, .06, .19], [.15, .13, .22], [.2, .24, .2]], [.034, .027, .02, .008], 5, .4, 0, rnd);

    // ten bronze coins stitched on the rim, faces to the front
    const coins = sc.mesh(bronzeTex, .8, 30, 'bronze_coins');
    for (let i = 0; i < 10; i++) {
      const a = i / 10 * Math.PI * 2 + (rnd() - .5) * .1;
      revolve(sc, coins, [[0, .066], [.034, .066], [.034, .04], [0, .04]], 5, 0, null, Math.cos(a) * .7, Math.sin(a) * .7);
    }

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['stag-shield'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -12, ry: 22, rx: 6, dist: 3.9, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -12, ry: 22, rx: 6, dist: 3.7, pivot: [0, 0] },
    },
  };
})(window);
