/*
 * Чёрный Клюв (Clan Raven sword), detailed pass. Blued falchion with a dotted damascus
 * pattern and a darker hooked beak tip, swept wing plates with trims, black wrapped grip
 * with silver wire, crow-beak pommel cap and five feathers tied to the guard.
 */
(function (global) {
  'use strict';
  const K = LPK, B = LPB;

  function build() {
    const rnd = LP.rng(1102);
    const sc = new LP.Scene();

    const bladeTex = K.metal(rnd, [44,58,84], { grain: 16, dark: .2, light: .12, w: 32, h: 128, draw: (x, w, h) => {
      // damascus-like dotted pattern in lighter blue
      x.fillStyle = 'rgba(120,150,190,.35)';
      for (let i = 0; i < 40; i++) x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 2, 1);
    } });
    const tipTex = K.metal(rnd, [24,28,40], { grain: 10, w: 16, h: 32 });
    const wingTex = K.metal(rnd, [34,38,48], { grain: 12, w: 32, h: 32 });
    const trimTex = K.metal(rnd, [120,126,140], { grain: 8, w: 16, h: 16, light: .2 });
    const wrapTex = K.wrap(rnd, [40,38,42], { pitch: 5, slope: .5, grain: 14, w: 32, h: 96 });
    const silverTex = K.flat(rnd, [186,190,200], 10, 8, 8);
    const featherTex = K.flat(rnd, [22,22,28], 12, 8, 8);
    const beakTex = K.metal(rnd, [60,62,70], { grain: 10, w: 16, h: 16 });

    // falchion: convex back on the left, hooked beak tip on the right
    // the tip curls out and down into a clear hook; the inner edge returns under it
    const blade = [[-.07,.03],[-.085,.55],[-.06,.95],[.01,1.18],[.12,1.24],[.24,1.22],[.32,1.16],[.38,1.04],[.3,1.09],[.24,1.04],[.2,1.12],[.12,1.06],[.1,.62],[.09,.03]];
    B.blade(sc, sc.mesh(bladeTex, .45, 18, 'blade'), blade, p => .012 + .006 * Math.max(0, 1 - p[1] / 1.2));
    // hook: three overlay pieces that step from steel into a soft glow at the very tip
    const hookA = K.metal(rnd, [60,84,112], { grain: 8, w: 16, h: 16 });
    const hookB = K.metal(rnd, [84,120,150], { grain: 8, w: 16, h: 16 });
    const hookGlow = K.flat(rnd, [120,230,240], 12, 8, 8);
    B.blade(sc, sc.mesh(hookA, .5, 20, 'hook_base'), [[.12,1.24],[.24,1.22],[.24,1.04],[.12,1.06]], p => .0135);
    B.blade(sc, sc.mesh(hookB, .5, 20, 'hook_mid'), [[.24,1.22],[.32,1.16],[.3,1.09],[.24,1.04]], p => .0135);
    B.blade(sc, sc.mesh(hookGlow, .2, 8, 'hook_glow', 1), [[.32,1.16],[.38,1.04],[.3,1.09]], p => .0135);

    // swept wing plates with a raised trim along the top edge
    const wing = sc.mesh(wingTex, .3, 10, 'wings');
    sc.box(wing, -.24, -.06, -.03, .02, -.03, .03);
    sc.box(wing, .06, .24, -.03, .02, -.03, .03);
    sc.box(wing, -.28, -.2, .02, .09, -.025, .025);
    sc.box(wing, .2, .28, .02, .09, -.025, .025);
    const trim = sc.mesh(trimTex, .5, 18, 'wing_trim');
    sc.box(trim, -.24, -.06, .02, .03, -.034, .034);
    sc.box(trim, .06, .24, .02, .03, -.034, .034);

    // black-wrapped grip with a silver wire spiral
    sc.prism(sc.mesh(wrapTex, .05, 4, 'grip'), 0, 0, -.42, -.03, .034, .034, 7);
    const wire = []; for (let i = 0; i <= 60; i++) { const t = i / 60, a = t * Math.PI * 2 * 8; wire.push([Math.cos(a) * .037, -.41 + t * .36, Math.sin(a) * .037]); }
    sc.tube(sc.mesh(silverTex, .6, 22, 'wire'), wire, wire.map(() => .005), 4, 0, 0, rnd);

    // crow-beak pommel cap
    sc.lathe(sc.mesh(beakTex, .35, 14, 'pommel'), [[0,-.56],[.06,-.5],[.07,-.46],[.03,-.42]], 8);
    const beak = sc.mesh(beakTex, .35, 14, 'beak');
    const m0 = sc.mark(beak);
    sc.lathe(beak, [[0,-.02],[.03,0],[.02,.05],[0,.07]], 5);
    sc.transform(beak, m0, p => [p[0], p[1] - .6, p[2] + .05]);

    // five feathers tied to the guard
    const feathers = sc.mesh(featherTex, .05, 4, 'feathers');
    for (let i = 0; i < 5; i++) {
      const x = -.12 + i * .06, tilt = (i - 2) * .12;
      const m1 = sc.mark(feathers);
      sc.lathe(feathers, [[0,-.16],[.03,-.08],[.035,.02],[.02,.08],[0,.12]], 5);
      sc.transform(feathers, m1, p => { const q = K.rotZ(p, tilt, [0, -.02]); return [q[0] + x, q[1] - .02, q[2] + .02]; });
    }

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['raven-sword'] = { build, views: LPB.views };
})(window);
