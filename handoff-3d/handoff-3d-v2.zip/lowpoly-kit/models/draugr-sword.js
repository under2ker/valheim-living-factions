/*
 * Ржавый Клинок (Draugr Court sword), detailed pass. Long pitted blade with a fuller,
 * crescent guard with a skull at the crossing and iron chain links, skull pommel with teeth
 * and glowing eye sockets, two tattered cloth ribbons.
 */
(function (global) {
  'use strict';
  const K = LPK, B = LPB;

  function build() {
    const rnd = LP.rng(1107);
    const sc = new LP.Scene();

    const rustTex = K.metal(rnd, [102,84,70], { grain: 18, rust: 60, dark: .24, w: 32, h: 128, draw: (x, w, h) => {
      // pitting
      x.fillStyle = 'rgba(40,30,26,.7)';
      for (let i = 0; i < 30; i++) x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 1, 2);
    } });
    const ironTex = K.metal(rnd, [78,74,70], { grain: 16, rust: 30, w: 32, h: 32 });
    const gripTex = K.wrap(rnd, [60,44,36], { pitch: 6, slope: .4, grain: 14, w: 32, h: 96 });
    const boneTex = K.flat(rnd, [206,196,172], 16, 16, 16);
    const toothTex = K.flat(rnd, [226,218,196], 10, 8, 8);
    const clothTex = K.flat(rnd, [70,64,58], 14, 16, 16);
    const clothTex2 = K.flat(rnd, [54,60,58], 12, 16, 16);
    const eyeTex = K.flat(rnd, [150,230,170], 16, 8, 8);
    const chainTex = K.metal(rnd, [90,88,84], { grain: 10, w: 16, h: 16 });

    // blade with a central fuller and pitted faces
    const blade = [[-.07,.04],[-.075,1.2],[-.03,1.38],[0,1.46],[.03,1.38],[.075,1.2],[.07,.04]];
    B.blade(sc, sc.mesh(rustTex, .2, 6, 'blade'), blade, p => .011 + .003 * K.hash2(p[0] * 21, p[1] * 7));
    sc.box(sc.mesh(ironTex, .2, 6, 'fuller'), -.012, .012, .18, 1.2, -.0125, .0125);

    // crescent guard: an arc of iron, with a skull at the crossing
    const arc = [];
    for (let i = 0; i <= 12; i++) { const a = -1.2 + i / 12 * 2.4; arc.push([Math.sin(a) * .24, .02 + (1 - Math.cos(a)) * .07, 0]); }
    sc.tube(sc.mesh(ironTex, .3, 12, 'crescent'), arc, arc.map(() => .028), 6, 0, 0, rnd);
    sc.box(sc.mesh(ironTex, .3, 12, 'guard_core'), -.03, .03, -.04, .04, -.03, .03);
    sc.lathe(sc.mesh(boneTex, .2, 8, 'guard_skull'), [[0,-.02],[.035,-.015],[.045,.01],[.035,.04],[0,.05]], 6, 0, .0, 0);
    for (const x of [-.02, .02]) sc.box(sc.mesh(eyeTex, .2, 8, 'guard_eyes', 1), x - .006, x + .006, .02, .03, .045, .05);

    // iron chain links hanging from the guard
    for (let i = 0; i < 3; i++) {
      const cy = -.1 - i * .08;
      const link = [];
      for (let k = 0; k <= 8; k++) { const a = k / 8 * Math.PI * 2; link.push([Math.cos(a) * .025, cy + Math.sin(a) * .035, 0]); }
      sc.tube(sc.mesh(chainTex, .4, 10, 'chain'), link, link.map(() => .007), 4, 0, 0, rnd);
    }

    // dark grip and skull pommel with teeth and glowing eye sockets
    sc.prism(sc.mesh(gripTex, .05, 4, 'grip'), 0, 0, -.42, -.04, .032, .032, 8);
    sc.lathe(sc.mesh(boneTex, .2, 8, 'skull'), [[0,-.62],[.05,-.6],[.075,-.55],[.07,-.5],[.04,-.46],[.02,-.43]], 9);
    sc.box(sc.mesh(boneTex, .2, 8, 'jaw'), -.04, .04, -.6, -.56, -.04, .02);
    for (let i = 0; i < 4; i++) sc.box(sc.mesh(toothTex, .3, 10, 'teeth'), -.03 + i * .02, -.02 + i * .02, -.605, -.592, .02, .04);
    sc.box(sc.mesh(eyeTex, .2, 8, 'eyes', 1), -.05, -.012, -.56, -.5, .055, .07);
    sc.box(sc.mesh(eyeTex, .2, 8, 'eyes2', 1), .012, .05, -.56, -.5, .055, .07);

    // two tattered cloth ribbons below the guard
    sc.ribbon(sc.mesh(clothTex, .05, 4, 'cloth'), [[.02,-.06,.03],[.035,-.14,.05],[.03,-.24,.08],[.045,-.3,.1]], [.05,.045,.04,.012], [1,0,0]);
    sc.ribbon(sc.mesh(clothTex2, .05, 4, 'cloth2'), [[-.02,-.06,-.03],[-.03,-.16,-.05],[-.035,-.22,-.07],[-.05,-.28,-.09]], [.045,.04,.03,.01], [1,0,0]);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['draugr-sword'] = { build, views: LPB.views };
})(window);
