/*
 * Обсидиановая Сабля (Fuling Horde sword), detailed pass. Curved saber with a sawtooth
 * back edge made of small chipped teeth, ochre war paint stripes on the leather grip,
 * bone guard with tusk ends, bone spike pommel and three trophy teeth on cords.
 */
(function (global) {
  'use strict';
  const K = LPK, B = LPB;

  function build() {
    const rnd = LP.rng(1104);
    const sc = new LP.Scene();

    const bladeTex = K.metal(rnd, [58,58,68], { grain: 20, light: .14, dark: .2, w: 32, h: 128, draw: (x, w, h) => {
      // glassy highlight streak along the cutting edge
      x.fillStyle = 'rgba(200,200,210,.18)';
      for (let i = 0; i < 10; i++) x.fillRect(w - 4 - (i % 3), 6 + i * 12, 2, 6);
    } });
    const toothTex = K.metal(rnd, [22,20,24], { grain: 14, w: 16, h: 16, light: .16 });
    const leatherTex = K.wrap(rnd, [112,92,62], { pitch: 6, slope: .5, grain: 16, w: 32, h: 96, draw: (x, w, h) => {
      // ochre war-paint stripes
      x.fillStyle = 'rgba(176,64,30,.85)';
      for (let k = 0; k < 3; k++) x.fillRect(4 + k * 9, 0, 3, h);
      for (let i = 0; i < 8; i++) x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 2, 2);
    } });
    const boneTex = K.flat(rnd, [222,210,184], 18, 16, 16);
    const cordTex = K.wrap(rnd, [120,92,58], { w: 8, h: 32, pitch: 3, slope: .9 });

    // curved saber body
    // blade base is centred on the grip axis (x = 0); the curve is shifted by the same amount
    const DX = -.05, SX = 1.5;   // blade is 50% wider than the first pass
    const blade = [[.03,.03],[-.03,.35],[-.1,.7],[-.13,.95],[-.1,1.12],[-.02,1.2],[.03,1.14],[-.04,1.02],[-.05,.85],[.0,.62],[.03,.4],[.07,.12],[.07,.03]].map(p => [p[0] * SX + DX, p[1]]);
    B.blade(sc, sc.mesh(bladeTex, .3, 10, 'blade'), blade, p => .016 + .01 * K.hash2(p[0] * 13, p[1] * 13));

    // sawtooth on the back: small chipped teeth along the convex side
    const back = [[-.1,.7],[-.13,.95],[-.1,1.12],[-.02,1.2]].map(p => [p[0] * SX + DX, p[1]]);
    const teeth = sc.mesh(toothTex, .2, 8, 'back_teeth');
    for (let i = 0; i < back.length - 1; i++) {
      const [ax, ay] = back[i], [bx, by] = back[i + 1];
      for (let k = 0; k < 4; k++) {
        const t = k / 4, x = ax + (bx - ax) * t, y = ay + (by - ay) * t;
        B.blade(sc, teeth, [[x, y],[x - .05, y + .02],[x + .006, y + .045]], p => .011);
      }
    }

    // bone guard block with tusk ends
    const bone = sc.mesh(boneTex, .2, 8, 'bone_guard');
    sc.box(bone, -.14, .12, -.04, .03, -.03, .03);
    for (const x of [-.15, .13]) sc.lathe(bone, [[0,-.02],[.02,-.005],[.025,.02],[.012,.035],[0,.04]], 5, x, 0);

    // lashings
    const cord = sc.mesh(cordTex, .05, 4, 'lashing');
    sc.tube(cord, [[-.02,-.04,.035],[.06,-.02,.04],[.08,.02,.035]], [.008,.008,.008], 4, 0, 0, rnd);
    sc.tube(cord, [[-.1,-.02,.035],[-.06,-.01,.04],[-.02,.01,.035]], [.008,.008,.008], 4, 0, 0, rnd);

    // grip wrapped in ochre leather with war-paint stripes
    sc.prism(sc.mesh(leatherTex, .05, 4, 'grip'), 0, 0, -.42, -.04, .032, .032, 8);

    // bone spike pommel
    sc.lathe(sc.mesh(boneTex, .2, 8, 'pommel_spike'), [[0,-.62],[.04,-.52],[.05,-.46],[.03,-.42]], 7);
    // glowing ember cap on the pommel tip
    const ember = K.flat(rnd, [246,150,64], 14, 8, 8);
    sc.lathe(sc.mesh(ember, .2, 8, 'pommel_glow', 1), [[0,-.63],[.03,-.58],[.045,-.52],[.035,-.47]], 6);

    // three trophy teeth on cords
    const tooth = sc.mesh(boneTex, .2, 8, 'teeth');
    const cords = [[-.1, -.14, .05], [-.02, -.2, .07], [.06, -.12, .05]];
    for (const [tx, ty, tz] of cords) {
      const m0 = sc.mark(tooth);
      sc.lathe(tooth, [[0,-.09],[.015,-.04],[.017,0],[.01,.02],[0,.03]], 5);
      sc.transform(tooth, m0, p => [p[0] + tx, p[1] + ty, p[2] + tz]);
    }

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['fuling-sword'] = { build, views: LPB.views };
})(window);
