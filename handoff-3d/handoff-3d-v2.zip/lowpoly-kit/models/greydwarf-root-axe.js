/*
 * Rootbiter («Корнеруб», Rótbítr) — Greydwarf Brood. Not forged at all: a knapped flint
 * slab lashed with living vines into a twisted root that is still growing — a sapling with
 * leaves sprouts from its top, roots splay from its foot, and a glowing amber "brood eye"
 * of resin sits in the binding.
 * Silhouette cue: organic and asymmetrical — grown, not made. No metal anywhere.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  function build() {
    const rnd = LP.rng(505);
    const sc = new LP.Scene();
    const { X, Y, S } = K.space(242, 380);

    const stone = [[226,112],[186,100],[150,86],[112,60],[84,56],[62,84],[46,126],[40,170],[50,214],[70,252],[100,276],[130,268],[156,236],[190,202],[226,200]].map(([x, y]) => [226 + (x - 226)*1.2, 156 + (y - 156)*1.12]);
    const BX0 = 4, BX1 = 226, BY0 = 44, BY1 = 290;

    const stoneTex = canvasTex(64, 80, (x, w, h) => {
      noiseFill(x, w, h, [70,78,90], 10, rnd);
      for (let i = 0; i < 46; i++) {                                       // flat knapped facets
        const cx = rnd()*w, cy = rnd()*h, r = 6 + rnd()*9, a0 = rnd()*6.283, g = 60 + rnd()*70;
        x.fillStyle = `rgba(${g},${g + 8},${g + 20},.55)`; x.beginPath();
        for (let k = 0; k < 5; k++) { const a = a0 + k/5*6.283, rr = r*(.6 + rnd()*.5); k ? x.lineTo(cx + Math.cos(a)*rr, cy + Math.sin(a)*rr*.7) : x.moveTo(cx + Math.cos(a)*rr, cy + Math.sin(a)*rr*.7); }
        x.closePath(); x.fill(); x.strokeStyle = 'rgba(24,28,36,.45)'; x.lineWidth = .8; x.stroke();
      }
      for (let i = 0; i < 40; i++) {                                       // conchoidal knapping scars
        const cx = rnd()*w, cy = rnd()*h, r = 2 + rnd()*5;
        x.fillStyle = rnd() < .5 ? 'rgba(40,46,54,.35)' : 'rgba(190,200,206,.28)';
        x.beginPath(); x.ellipse(cx, cy, r, r*.6, rnd()*3, 0, 6.283); x.fill();
        x.strokeStyle = 'rgba(30,34,40,.4)'; x.lineWidth = .8; x.beginPath(); x.arc(cx, cy, r, 0, 2); x.stroke();
      }
      const sx = v => (v - BX0) / (BX1 - BX0) * w, sy = v => (v - BY0) / (BY1 - BY0) * h;
      x.beginPath(); stone.slice(3, 11).forEach((p, i) => i ? x.lineTo(sx(p[0]), sy(p[1])) : x.moveTo(sx(p[0]), sy(p[1])));
      x.strokeStyle = 'rgba(214,222,228,.8)'; x.lineWidth = 3; x.stroke();
      for (let i = 0; i < 14; i++) { x.fillStyle = 'rgba(86,120,52,.6)'; x.fillRect(Math.floor(rnd()*w*.4 + w*.55), Math.floor(rnd()*h), 2 + Math.floor(rnd()*3), 2); } // moss near the binding
    });
    const barkTex = K.wood(rnd, [88,80,62], { w: 24, h: 128, grain: 24, streaks: 30, draw: (x, w, h) => {
      for (let i = 0; i < 30; i++) { x.fillStyle = rnd() < .6 ? 'rgba(78,122,50,.75)' : 'rgba(30,26,18,.6)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2 + Math.floor(rnd()*4), 2 + Math.floor(rnd()*4)); } } });
    const vineTex = K.wrap(rnd, [70,112,46], { w: 8, h: 32, pitch: 4, slope: .5 });
    // glowing vine and petal textures (fixed colour, no rnd draws, so the geometry stays the same)
    const vineGlowTex = LP.canvasTex(8, 8, (x, w, h) => { x.fillStyle = 'rgb(128,246,120)'; x.fillRect(0, 0, w, h); });
    const leafGlowTex = LP.canvasTex(8, 8, (x, w, h) => { x.fillStyle = 'rgb(96,200,90)'; x.fillRect(0, 0, w, h); });
    const leafTex = canvasTex(16, 32, (x, w, h) => { noiseFill(x, w, h, [76,130,52], 18, rnd);
      x.fillStyle = 'rgba(200,230,140,.6)'; x.fillRect(w/2 - 1, 0, 1, h); for (let j = 4; j < h; j += 5) { x.fillRect(w/2 - 5, j, 4, 1); x.fillRect(w/2 + 1, j + 2, 4, 1); } });
    const amberTex = canvasTex(8, 8, (x, w, h) => { noiseFill(x, w, h, [255,184,64], 40, rnd); x.fillStyle = '#fff3c0'; x.fillRect(2, 2, 2, 2); });

    // twisted root haft
    const bark = sc.mesh(barkTex, .04, 4, 'root_haft');
    const hp = [], hr = [], N = 14;
    for (let k = 0; k <= N; k++) { const t = k/N; hp.push([.035*Math.sin(t*7.5) + .01*Math.sin(t*19), Y(690) + t*(Y(30) - Y(690)), .02*Math.cos(t*6)]); hr.push(.06 - .026*t + .012*Math.sin(t*13)); }
    sc.tube(bark, hp, hr, 6, .55, .26, rnd);
    // splayed roots at the foot
    [[-.7, .06], [.5, -.05], [2.3, .04]].forEach(([a, lean]) => {
      const p0 = hp[1];
      sc.tube(bark, [p0, [p0[0] + Math.cos(a)*.06, Y(722), p0[2] + Math.sin(a)*.06], [p0[0] + Math.cos(a)*.12 + lean, Y(770), p0[2] + Math.sin(a)*.12]], [.03,.018,.004], 5, .3, .2, rnd);
    });
    // sapling sprouting from the top: twig + three leaves
    const top = hp[N];
    sc.tube(bark, [top, [top[0] + .03, Y(-10), top[2]], [top[0] + .09, Y(-40), top[2] + .02]], [.022,.012,.004], 5, .3, .1, rnd);
    const leaves = sc.mesh(leafGlowTex, .15, 8, 'leaves', 1);
    [[top[0] + .03, Y(-6), 1.1, .2], [top[0] + .08, Y(-34), .2, -.5], [top[0] + .01, Y(10), -.9, .6]].forEach(([lx, ly, ang, yaw]) => {
      const m0 = sc.mark(leaves), L = .17, wv = .05;
      sc.extrude(leaves, [[0,0],[wv*.7,L*.25],[wv,L*.55],[wv*.4,L*.9],[0,L],[-wv*.4,L*.9],[-wv,L*.55],[-wv*.7,L*.25]], () => .003, p => [(p[0] + wv)/(2*wv), p[1]/L]);
      sc.transform(leaves, m0, p => { let q = K.rotZ(p, ang); q = K.rotY(q, yaw); return [q[0] + lx, q[1] + ly, q[2]]; });
    });

    // knapped flint head: wedge + per-vertex jitter => irregular facets
    const bx0 = X(BX0), bx1 = X(BX1), by0 = Y(BY1), by1 = Y(BY0);
    sc.extrude(sc.mesh(stoneTex, .25, 10, 'flint_head'), stone.map(p => S(p[0], p[1])),
      p => { const t = Math.max(0, Math.min(1, (p[0] - bx0) / (X(226) - bx0))); return .006 + .04*t + .006*K.hash2(p[0]*13, p[1]*7); },
      p => [(p[0] - bx0) / (bx1 - bx0), (p[1] - by0) / (by1 - by0)]);

    // vine lashing: two opposite helices = cross-binding
    const vine = sc.mesh(vineGlowTex, .2, 8, 'vines', 1);
    for (const dir of [1, -1]) {
      const v = []; for (let i = 0; i <= 50; i++) { const t = i/50, a = dir*t*Math.PI*2*3.5; v.push([X(242) + Math.cos(a)*.075, Y(214) + t*(Y(96) - Y(214)), Math.sin(a)*.075]); }
      sc.tube(vine, v, v.map(() => .011), 4, 0, .15, rnd);
    }
    sc.tube(vine, [[X(232),Y(214),.07],[X(214),Y(250),.09],[X(206),Y(300),.08],[X(212),Y(330),.06]], [.009,.008,.006,.003], 4, 0, .1, rnd);  // trailing tendril
    // glowing amber "brood eye" on both faces of the binding
    const amber = sc.mesh(amberTex, 0, 1, 'brood_eye', 1);
    for (const z of [.082, -.082]) { const m0 = sc.mark(amber);
      sc.lathe(amber, [[0,-.05],[.042,-.02],[.048,.01],[.032,.04],[0,.052]], 6);
      sc.transform(amber, m0, p => [p[0] + X(244), p[1] + Y(156), p[2]*.55 + z]); }
    // glow accents (appended last so earlier random draws are unchanged)
    LPG.accents(sc, rnd, { X, Y, S }, {
      name: 'greydwarf', color: [128,246,120],
      spines: [], bz: 0.02, br: 0.006,
      grip: [330,318], gr: 0.03,
      gem: [242,250], gz: 0.04, gs: 0.022,
    });
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['greydwarf-root-axe'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -30, ry: 22, rx: 8, dist: 4.9, pivot: [.2, -.05] },
      icon: { w: 512, h: 512, rz: -42, ry: 22, rx: 8, dist: 4.6, pivot: [.2, -.05], offset: [-.12, -.08] },
    },
  };
})(window);
