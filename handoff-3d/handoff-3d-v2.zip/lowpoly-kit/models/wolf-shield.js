/*
 * Wolf-hide shield («Щит Волчьей Шкуры», Clan Wolf). A round wooden board under a whole grey
 * wolf pelt, the fur hanging off the bottom rim as a tail, bound by a hammered iron band and
 * a domed iron boss. Silhouette cue: a convex disc with one ragged tail below it.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  // revolve a [r, z] profile around the Z axis (the shield's face normal), centred at (cx, cy).
  // jit > 0 adds per-vertex radial noise from rnd, so the hide edge stays ragged.
  function revolve(sc, m, prof, seg, jit = 0, rnd = null, cx = 0, cy = 0) {
    const G = prof.map(([r, z]) => {
      const row = [];
      for (let i = 0; i < seg; i++) {
        const a = i / seg * Math.PI * 2, j = jit ? 1 + jit * (rnd() * 2 - 1) : 1;
        row.push([cx + Math.cos(a) * r * j, cy + Math.sin(a) * r * j, z]);
      }
      return row;
    });
    for (let k = 0; k < G.length - 1; k++) for (let i = 0; i < seg; i++) {
      const i1 = (i + 1) % seg, v0 = k / (G.length - 1), v1 = (k + 1) / (G.length - 1);
      const u0 = i / seg, u1 = (i + 1) / seg;
      sc.quad(m, G[k][i], G[k][i1], G[k + 1][i1], G[k + 1][i], [u0, v0], [u1, v0], [u1, v1], [u0, v1]);
    }
  }

  // torus in the XY plane: ring radius R, tube radius r.
  function torus(sc, m, R, r, nM, nm) {
    const P = [];
    for (let j = 0; j < nM; j++) {
      const a = j / nM * Math.PI * 2, row = [];
      for (let i = 0; i < nm; i++) {
        const b = i / nm * Math.PI * 2, q = R + r * Math.cos(b);
        row.push([Math.cos(a) * q, Math.sin(a) * q, r * Math.sin(b)]);
      }
      P.push(row);
    }
    for (let j = 0; j < nM; j++) for (let i = 0; i < nm; i++) {
      const j1 = (j + 1) % nM, i1 = (i + 1) % nm;
      sc.quad(m, P[j][i], P[j][i1], P[j1][i1], P[j1][i], [j / nM, i / nm], [j / nM, (i + 1) / nm], [(j + 1) / nM, (i + 1) / nm], [(j + 1) / nM, i / nm]);
    }
  }

  function build() {
    const rnd = LP.rng(1201);
    const sc = new LP.Scene();

    // textures, in a fixed order
    const woodTex = K.wood(rnd, [96, 68, 42], { w: 24, h: 96, grain: 18, streaks: 22 });
    const furTex = K.wrap(rnd, [122, 118, 110], { w: 32, h: 32, pitch: 4, slope: .5, grain: 30, draw: (x, w, h) => {
      for (let i = 0; i < 40; i++) { x.fillStyle = 'rgba(224,220,210,.35)'; x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 1, 2 + Math.floor(rnd() * 3)); }
      for (let i = 0; i < 20; i++) { x.fillStyle = 'rgba(40,36,34,.35)'; x.fillRect(Math.floor(rnd() * w), Math.floor(rnd() * h), 1, 2); }
    } });
    const ironTex = K.metal(rnd, [70, 72, 74], { grain: 20, rust: 12 });
    const bossTex = K.metal(rnd, [104, 106, 110], { grain: 14, light: .2 });
    const tailTex = K.wrap(rnd, [90, 86, 78], { w: 12, h: 32, pitch: 3, slope: .8, grain: 24 });

    // wooden board: thick, rounded rim
    const wood = sc.mesh(woodTex, .1, 6, 'wood_disc');
    revolve(sc, wood, [[0, -.035], [.5, -.035], [.66, -.025], [.7, -.008], [.7, .008], [.66, .025], [.5, .035], [0, .035]], 16);

    // pelt laid over the front, jittered edge, convex
    const hide = sc.mesh(furTex, .05, 4, 'wolf_hide');
    revolve(sc, hide, [[.7, 0], [.68, .024], [.6, .042], [.5, .048], [.3, .052], [0, .054]], 16, .05, rnd);

    // hammered iron band around the rim
    const rim = sc.mesh(ironTex, .4, 14, 'iron_rim');
    torus(sc, rim, .7, .032, 16, 6);

    // domed iron boss
    const boss = sc.mesh(bossTex, .6, 20, 'iron_boss');
    revolve(sc, boss, [[.2, .03], [.17, .06], [.1, .085], [.05, .1], [0, .11]], 10);

    // fur tail hanging from the bottom rim
    const tail = sc.mesh(tailTex, .05, 4, 'fur_tail');
    const tp = [[0, -.66, .02], [.02, -.78, .03], [.05, -.9, .05], [.04, -1.0, .04], [0, -1.08, .02], [-.03, -1.12, 0]];
    sc.tube(tail, tp, [.06, .065, .07, .065, .05, .03], 5, 0, .25, rnd);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['wolf-shield'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -12, ry: 24, rx: 6, dist: 4.5, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -12, ry: 24, rx: 6, dist: 4.2, pivot: [0, 0] },
    },
  };
})(window);
