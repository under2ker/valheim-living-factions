/*
 * Grey Pack Bow («Лук Серой Стаи», Clan Wolf). A long hunting bow of pale ash: even limbs,
 * a grip wrapped in worn grey leather, a wolf-pelt strip tied just under the upper nock, and a
 * thin string with a slight twist. Silhouette cue: one long, unbroken ")" with nothing extra.
 */
(function (global) {
  'use strict';
  const K = LPK;

  // upper limb centreline in the XY plane (x = belly side, y = up); the lower limb mirrors it
  const UPPER = [[0,0],[.12,.16],[.19,.42],[.15,.74],[.03,1.0],[-.05,1.1]];

  // Catmull-Rom through 2D control points, `per` samples per span
  function cr(a, b, c, d, t) {
    const t2 = t*t, t3 = t2*t;
    return [0,1].map(i => .5*(2*b[i] + (-a[i]+c[i])*t + (2*a[i]-5*b[i]+4*c[i]-d[i])*t2 + (-a[i]+3*b[i]-3*c[i]+d[i])*t3));
  }
  function spline(ctrl, per) {
    const P = [ctrl[0], ...ctrl, ctrl[ctrl.length-1]], out = [];
    for (let s = 0; s < ctrl.length-1; s++) for (let j = 0; j < per; j++) out.push(cr(P[s], P[s+1], P[s+2], P[s+3], j/per));
    out.push(ctrl[ctrl.length-1]); return out;
  }
  const limb = (ctrl, per) => spline(ctrl, per).map(([x,y]) => [x,y,0]);
  const mirrorY = pts => pts.map(([x,y,z]) => [x,-y,z]);
  const taper = (n, a, b) => Array.from({length: n}, (_, k) => a + (b-a)*Math.pow(k/(n-1), 1.1));

  function build() {
    const rnd = LP.rng(1301);
    const sc = new LP.Scene();

    const ashTex = K.wood(rnd, [150, 126, 88], { w: 24, h: 64, grain: 16, streaks: 22 });
    const leatherTex = K.wrap(rnd, [116, 114, 108], { w: 24, h: 48, pitch: 5, slope: .5, grain: 14 });
    const furTex = K.flat(rnd, [122, 114, 102], 40, 16, 16);
    const cordTex = K.wrap(rnd, [196, 192, 182], { w: 8, h: 16, pitch: 2, slope: .8, grain: 10 });
    const nockTex = K.flat(rnd, [184, 160, 116], 14, 8, 8);

    // ash limbs: one tube per limb, tapering from the grip to the nock
    const up = limb(UPPER, 4), low = mirrorY(up), n = up.length;
    const r = taper(n, .034, .014);
    const limbs = sc.mesh(ashTex, .25, 10, 'limbs');
    sc.tube(limbs, up, r, 6, 0, 0, rnd);
    sc.tube(limbs, low, r, 6, 0, 0, rnd);

    // grey leather grip
    const grip = sc.mesh(leatherTex, .1, 6, 'grip_wrap');
    sc.tube(grip, [[0,-.14,0],[0,-.05,0],[0,.05,0],[0,.14,0]], [.04,.043,.043,.04], 6, 0, 0, rnd);

    // wolf pelt: a sinew tie round the limb, then a furred strip hanging in front of it
    const pelt = sc.mesh(furTex, .05, 4, 'wolf_pelt');
    const t = up[n-4];
    sc.tube(pelt, [up[n-5], up[n-4], up[n-3]], [.018,.02,.018], 6, 0, 0, rnd);
    sc.tube(pelt, [[t[0]+.005, t[1]-.01, .02], [t[0]+.01, t[1]-.12, .045], [t[0]+.004, t[1]-.24, .05], [t[0]+.02, t[1]-.32, .06]],
      [.016,.019,.015,.007], 5, 0, .3, rnd);

    // string: thin tube, slight twist, from nock to nock
    const string = sc.mesh(cordTex, .15, 8, 'string');
    const sp = Array.from({length: 13}, (_, i) => [-.05, 1.1 - 2.2*i/12, 0]);
    sc.tube(string, sp, sp.map(() => .0055), 4, .2, 0, rnd);

    // pale nocks at both tips
    const nocks = sc.mesh(nockTex, .1, 6, 'nocks');
    for (const p of [up[n-1], low[n-1]]) sc.lathe(nocks, [[0,p[1]-.02],[.016,p[1]-.01],[.014,p[1]+.01],[0,p[1]+.02]], 5, p[0]);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['wolf-bow'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -6, ry: 24, rx: 6, dist: 4.6, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -40, ry: 22, rx: 8, dist: 4.4, pivot: [0, 0] },
    },
  };
})(window);
