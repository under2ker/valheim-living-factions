/*
 * Bone shield («Костяной Щит», Fuling Horde), tidy pass. A round shield made almost entirely of
 * one clean piece of bone: an ivory disc with fine grain, a neat bead rim with evenly spaced
 * bone pegs, a domed bone boss and two bone tusks crossed neatly above the top edge.
 * Silhouette cue: a smooth, symmetrical disc, bone-pale all over, with nothing rusted or lashed.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  // revolve a [r, z] profile around the Z axis (smooth, no jitter)
  function revolve(sc, m, prof, seg) {
    const G = prof.map(([r, z]) => {
      const row = [];
      for (let i = 0; i < seg; i++) { const a = i / seg * Math.PI * 2; row.push([Math.cos(a) * r, Math.sin(a) * r, z]); }
      return row;
    });
    for (let k = 0; k < G.length - 1; k++) for (let i = 0; i < seg; i++) {
      const i1 = (i + 1) % seg, v0 = k / (G.length - 1), v1 = (k + 1) / (G.length - 1);
      const u0 = i / seg, u1 = (i + 1) / seg;
      sc.quad(m, G[k][i], G[k][i1], G[k + 1][i1], G[k + 1][i], [u0, v0], [u1, v0], [u1, v1], [u0, v1]);
    }
  }

  function build() {
    const rnd = LP.rng(1204);
    const sc = new LP.Scene();

    // one clean piece of bone: ivory with fine grain and a few dark growth lines
    const boneTex = canvasTex(32, 32, (x, w, h) => {
      noiseFill(x, w, h, [218, 206, 180], 6, rnd);
      x.strokeStyle = 'rgba(120,100,72,.35)'; x.lineWidth = 1;
      for (let i = 0; i < 4; i++) { x.beginPath(); x.moveTo(0, 6 + i * 8); x.lineTo(w, 4 + i * 8 + rnd() * 3); x.stroke(); }
    });
    const boneDark = K.flat(rnd, [178, 164, 136], 8, 16, 16);
    const cordTex = K.wrap(rnd, [96, 70, 44], { w: 8, h: 24, pitch: 3, slope: .9, grain: 10 });

    // smooth round disc with a slight dish
    const disc = [];
    for (let i = 0; i < 40; i++) { const a = i / 40 * Math.PI * 2; disc.push([Math.cos(a) * .66, Math.sin(a) * .66]); }
    sc.extrude(sc.mesh(boneTex, .25, 10, 'bone_disc'), disc, p => .04 - .01 * (Math.hypot(p[0], p[1]) / .66), p => [(p[0] + .7) / 1.4, (p[1] + .7) / 1.4]);

    // bead rim around the edge
    revolve(sc, sc.mesh(boneTex, .3, 12, 'bone_rim'), [[.66, -.02], [.7, 0], [.67, .03], [.62, .03]], 40);

    // evenly spaced bone pegs on the rim, one per 20 degrees
    const pegs = sc.mesh(boneDark, .2, 8, 'rim_pegs');
    for (let i = 0; i < 18; i++) {
      const a = i / 18 * Math.PI * 2;
      const m0 = sc.mark(pegs);
      sc.lathe(pegs, [[0, -.012], [.02, -.004], [.022, .01], [.012, .02], [0, .024]], 5);
      sc.transform(pegs, m0, p => [p[0] + Math.cos(a) * .7, p[1] + Math.sin(a) * .7, p[2] + .03]);
    }

    // thin cord running round the rim between the pegs
    const ring = [];
    for (let i = 0; i <= 60; i++) { const a = i / 60 * Math.PI * 2; ring.push([Math.cos(a) * .665, Math.sin(a) * .665, .028]); }
    sc.tube(sc.mesh(cordTex, .05, 4, 'rim_cord'), ring, ring.map(() => .006), 4, 0, 0, rnd);

    // domed bone boss in the centre
    revolve(sc, sc.mesh(boneTex, .3, 12, 'bone_boss'), [[.15, .03], [.13, .07], [.08, .1], [.04, .115], [0, .12]], 14);

    // two bone tusks crossed neatly above the top edge
    const tusks = sc.mesh(boneTex, .3, 12, 'bone_tusks');
    sc.tube(tusks, [[-.36, .5, .05], [-.16, .76, .09], [.06, .9, .12], [.24, 1.02, .12]], [.045, .045, .035, .01], 6, 0, 0, rnd);
    sc.tube(tusks, [[.36, .5, .05], [.16, .76, .09], [-.06, .9, .12], [-.24, 1.02, .12]], [.045, .045, .035, .01], 6, 0, 0, rnd);

    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['fuling-shield'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -10, ry: 22, rx: 6, dist: 4.4, pivot: [0, -.12] },
      icon: { w: 512, h: 512, rz: -10, ry: 22, rx: 6, dist: 4.2, pivot: [0, -.12] },
    },
  };
})(window);
