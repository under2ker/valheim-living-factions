/*
 * Sinew Bow («Сухожильный Лук», Fuling Horde). A short, crude raider's bow: two rough branch
 * limbs with a deep belly, the grip bound with sinew, and a rawhide cord hanging from one limb
 * with bone beads and a trophy tooth on it. Silhouette cue: a stubby, lopsided ")" with
 * something dangling off the upper limb.
 */
(function (global) {
  'use strict';
  const K = LPK;

  // deep-bellied short limb; the lower limb is its mirror
  const UPPER = [[0,0],[.16,.16],[.26,.44],[.2,.78],[.06,1.02],[-.04,1.1]];

  function cr(a, b, c, d, t) {
    const t2 = t*t, t3 = t2*t;
    return [0,1].map(i => .5*(2*b[i] + (-a[i]+c[i])*t + (2*a[i]-5*b[i]+4*c[i]-d[i])*t2 + (-a[i]+3*b[i]-3*c[i]+d[i])*t3));
  }
  function spline(ctrl, per) {
    const P = [ctrl[0], ...ctrl, ctrl[ctrl.length-1]], out = [];
    for (let s = 0; s < ctrl.length-1; s++) for (let j = 0; j < per; j++) out.push(cr(P[s], P[s+1], P[s+2], P[s+3], j/per));
    out.push(ctrl[ctrl.length-1]); return out;
  }
  const limb = (ctrl, per) => spline(ctrl, per).map(([x,y]) => [x,y,0]);
  const mirrorY = pts => pts.map(([x,y,z]) => [x,-y,z]);
  const taper = (n, a, b) => Array.from({length: n}, (_, k) => a + (b-a)*Math.pow(k/(n-1), 1.1));

  function build() {
    const rnd = LP.rng(1304);
    const sc = new LP.Scene();

    const branchTex = K.wood(rnd, [96, 72, 48], { w: 24, h: 64, grain: 22, streaks: 26, draw: (x, w, h) => {
      for (let i = 0; i < 10; i++) { x.fillStyle = 'rgba(30,20,12,.8)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2, 2); } } });
    const sinewTex = K.wrap(rnd, [168, 140, 96], { w: 16, h: 24, pitch: 3, slope: 1, grain: 14 });
    const cordTex = K.wrap(rnd, [90, 70, 48], { w: 8, h: 16, pitch: 2, slope: .9, grain: 10 });
    const boneTex = K.flat(rnd, [222, 210, 184], 18, 16, 16);
    const toothTex = K.flat(rnd, [236, 228, 206], 10, 8, 8);

    // rough branch limbs: jittered tube, slight twist
    const up = limb(UPPER, 4), low = mirrorY(up);
    const limbs = sc.mesh(branchTex, .08, 4, 'limbs');
    sc.tube(limbs, up, taper(up.length, .04, .018), 5, .3, .22, rnd);
    sc.tube(limbs, low, taper(low.length, .04, .018), 5, .3, .22, rnd);

    // sinew binding: a helix round the grip
    const sinew = sc.mesh(sinewTex, .05, 4, 'sinew_wrap');
    const helix = []; for (let i = 0; i <= 24; i++) { const t = i/24, a = t*Math.PI*2*6; helix.push([Math.cos(a)*.042, -.16 + t*.32, Math.sin(a)*.042]); }
    sc.tube(sinew, helix, helix.map(() => .013), 4, 0, 0, rnd);

    // rawhide cord hanging from the upper limb (at its curve, near y 0.78)
    const p = up[12];
    const C0 = [p[0] + .02, p[1], .03], C1 = [p[0] + .05, p[1] - .2, .07], C2 = [p[0] + .06, p[1] - .38, .09];
    const cord = sc.mesh(cordTex, .05, 4, 'cord');
    sc.tube(cord, [C0, C1, C2], [.006,.006,.006], 4, 0, 0, rnd);

    // bone beads on the cord
    const bone = sc.mesh(boneTex, .3, 12, 'bone_pieces');
    const bead = (c, s) => sc.lathe(bone, [[0,c[1]-.03*s],[.012*s,c[1]-.01*s],[.013*s,c[1]+.01*s],[0,c[1]+.03*s]], 5, c[0], c[2]);
    bead([(C0[0]+C1[0])/2, (C0[1]+C1[1])/2, (C0[2]+C1[2])/2], 1);
    bead(C1, 1.3);

    // trophy tooth at the cord's end: pointed downward, root threaded on the cord
    const tooth = sc.mesh(toothTex, .2, 8, 'trophy_tooth');
    const yb = C2[1] + .03;
    sc.lathe(tooth, [[0,yb-.13],[.012,yb-.07],[.02,yb],[.018,yb+.05],[.006,yb+.07],[0,yb+.07]], 5, C2[0], C2[2]);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['fuling-bow'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -6, ry: 24, rx: 6, dist: 4.6, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -40, ry: 22, rx: 8, dist: 4.4, pivot: [0, 0] },
    },
  };
})(window);
