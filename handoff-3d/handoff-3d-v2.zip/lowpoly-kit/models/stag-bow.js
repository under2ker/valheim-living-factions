/*
 * Antler Bow («Рогатый Лук», Clan Stag). A composite-style bow: laminated horn-brown limbs
 * that taper from the grip, a grip insert of deer antler with tines at the handle, bronze caps
 * on both limb tips and a thin pale string. Silhouette cue: the forked antler handle at the
 * centre and the bright bronze tips.
 */
(function (global) {
  'use strict';
  const K = LPK;

  // composite limbs: short bend, tips leaning slightly forward at the nocks
  const UPPER = [[0,0],[.10,.16],[.12,.46],[.04,.82],[-.02,.98],[0,1.1]];

  function cr(a, b, c, d, t) {
    const t2 = t*t, t3 = t2*t;
    return [0,1].map(i => .5*(2*b[i] + (-a[i]+c[i])*t + (2*a[i]-5*b[i]+4*c[i]-d[i])*t2 + (-a[i]+3*b[i]-3*c[i]+d[i])*t3));
  }
  function spline(ctrl, per) {
    const P = [ctrl[0], ...ctrl, ctrl[ctrl.length-1]], out = [];
    for (let s = 0; s < ctrl.length-1; s++) for (let j = 0; j < per; j++) out.push(cr(P[s], P[s+1], P[s+2], P[s+3], j/per));
    out.push(ctrl[ctrl.length-1]); return out;
  }
  const limb = (ctrl, per) => spline(ctrl, per).map(([x,y]) => [x,y,0]);
  const mirrorY = pts => pts.map(([x,y,z]) => [x,-y,z]);
  const taper = (n, a, b) => Array.from({length: n}, (_, k) => a + (b-a)*Math.pow(k/(n-1), 1.1));

  function build() {
    const rnd = LP.rng(1303);
    const sc = new LP.Scene();

    const hornTex = K.wood(rnd, [130, 100, 70], { w: 24, h: 64, grain: 16, streaks: 16, draw: (x, w, h) => {
      for (let j = 0; j < h; j += 9) { x.fillStyle = 'rgba(60,40,24,.5)'; x.fillRect(0, j, w, 1); } } });
    const antlerTex = K.wood(rnd, [196, 178, 144], { w: 16, h: 32, grain: 14, streaks: 12, draw: (x, w, h) => {
      for (let i = 0; i < 10; i++) { x.fillStyle = 'rgba(80,60,40,.7)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1, 2 + Math.floor(rnd()*3)); } } });
    const bronzeTex = K.metal(rnd, [150, 114, 66], { w: 16, h: 16, grain: 14, blotches: 20 });
    const stringTex = K.wrap(rnd, [206, 196, 170], { w: 8, h: 16, pitch: 2, slope: .8, grain: 8 });

    // composite limbs: 5-sided tubes read as laminated horn
    const up = limb(UPPER, 4), low = mirrorY(up), n = up.length;
    const r = taper(n, .04, .016);
    const limbs = sc.mesh(hornTex, .2, 10, 'limbs');
    sc.tube(limbs, up, r, 5, 0, 0, rnd);
    sc.tube(limbs, low, r, 5, 0, 0, rnd);

    // antler grip insert along the handle
    const antler = sc.mesh(antlerTex, .15, 8, 'antler_grip');
    sc.tube(antler, [[.02,-.2,0],[.02,-.1,0],[.02,0,0],[.02,.1,0],[.02,.2,0]], [.022,.03,.034,.03,.022], 6, 0, 0, rnd);

    // antler tines branching from the grip insert
    const tines = sc.mesh(antlerTex, .15, 8, 'antler_tines');
    sc.tube(tines, [[.04,.10,0],[.13,.17,.03],[.16,.24,.04]], [.018,.012,.004], 4, 0, 0, rnd);
    sc.tube(tines, [[.05,-.04,.02],[.14,-.10,.03],[.17,-.14,.05]], [.017,.011,.004], 4, 0, 0, rnd);
    sc.tube(tines, [[.01,.04,-.02],[-.06,.08,-.04],[-.08,.10,-.05]], [.016,.01,.004], 4, 0, 0, rnd);

    // bronze caps on both tips
    const caps = sc.mesh(bronzeTex, .4, 16, 'bronze_caps');
    for (const p of [up[n-1], low[n-1]]) sc.lathe(caps, [[0,p[1]-.03],[.024,p[1]-.02],[.026,p[1]+.01],[.018,p[1]+.025],[0,p[1]+.035]], 6, p[0]);

    // string: thin pale tube, from nock to nock
    const string = sc.mesh(stringTex, .15, 8, 'string');
    const sp = Array.from({length: 13}, (_, i) => [0, 1.1 - 2.2*i/12, 0]);
    sc.tube(string, sp, sp.map(() => .0055), 4, .15, 0, rnd);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['stag-bow'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -6, ry: 24, rx: 6, dist: 4.6, pivot: [0, 0] },
      icon: { w: 512, h: 512, rz: -40, ry: 22, rx: 8, dist: 4.4, pivot: [0, 0] },
    },
  };
})(window);
