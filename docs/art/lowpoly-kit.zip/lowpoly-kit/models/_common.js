/*
 * Shared texture recipes and helpers for item models. All take the model's own seeded `rnd`
 * so each model stays deterministic. Colours are [r,g,b] 0–255.
 * (wolf-fang-axe.js predates this file and keeps its own inline recipes on purpose.)
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;

  const K = {
    /** Svg-space → model-space converters. 300 svg units = 1 model unit, haft on x=cx. */
    space(cx = 242, cy = 380) {
      const X = v => (v - cx) / 300, Y = v => -(v - cy) / 300;
      return { X, Y, S: (x, y) => [X(x), Y(y)] };
    },

    /** Painterly metal: base grain + 2–4 px blotches + pits + scratches. */
    metal(rnd, base, o = {}) {
      const w = o.w || 32, h = o.h || 32;
      return canvasTex(w, h, (x) => {
        noiseFill(x, w, h, base, o.grain ?? 16, rnd);
        for (let i = 0; i < (o.blotches ?? w*h/12); i++) {
          x.fillStyle = rnd() < .5 ? `rgba(0,0,0,${o.dark ?? .18})` : `rgba(255,255,255,${o.light ?? .1})`;
          x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2 + Math.floor(rnd()*3), 2 + Math.floor(rnd()*3));
        }
        if (o.rust) for (let i = 0; i < o.rust; i++) {
          x.fillStyle = rnd() < .6 ? 'rgba(122,62,24,.55)' : 'rgba(70,120,96,.45)';
          x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1 + Math.floor(rnd()*4), 1 + Math.floor(rnd()*3));
        }
        if (o.draw) o.draw(x, w, h);
      });
    },

    /** Wood with long grain streaks along v. */
    wood(rnd, base, o = {}) {
      const w = o.w || 24, h = o.h || 160;
      return canvasTex(w, h, (x) => {
        noiseFill(x, w, h, base, o.grain ?? 16, rnd);
        for (let i = 0; i < (o.streaks ?? 16); i++) {
          x.fillStyle = rnd() < .5 ? 'rgba(0,0,0,.35)' : 'rgba(255,230,190,.18)';
          x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1, 16 + Math.floor(rnd()*60));
        }
        if (o.draw) o.draw(x, w, h);
      });
    },

    /** Diagonal wrap (leather, cloth, rope). */
    wrap(rnd, base, o = {}) {
      const w = o.w || 32, h = o.h || 64, pitch = o.pitch || 6;
      return canvasTex(w, h, (x) => {
        noiseFill(x, w, h, base, o.grain ?? 14, rnd);
        for (let k = -12; k < h/pitch + 4; k++) {
          x.fillStyle = 'rgba(0,0,0,.6)'; for (let i = 0; i < w; i++) x.fillRect(i, Math.floor(k*pitch + i*(o.slope ?? .35)), 1, 1);
          x.fillStyle = 'rgba(255,255,255,.18)'; for (let i = 0; i < w; i++) x.fillRect(i, Math.floor(k*pitch + i*(o.slope ?? .35)) + 2, 1, 1);
        }
        if (o.draw) o.draw(x, w, h);
      });
    },

    /** Flat colour with light noise — for small trims, glows, gems. */
    flat(rnd, base, amp = 12, w = 8, h = 8) { return canvasTex(w, h, (x) => noiseFill(x, w, h, base, amp, rnd)); },

    /** Rotate point p around the Z axis by a (radians) about centre c. */
    rotZ(p, a, c = [0, 0]) { const s = Math.sin(a), co = Math.cos(a), dx = p[0]-c[0], dy = p[1]-c[1]; return [c[0] + dx*co - dy*s, c[1] + dx*s + dy*co, p[2]]; },
    /** Rotate around the Y axis. */
    rotY(p, a, c = [0, 0]) { const s = Math.sin(a), co = Math.cos(a), dx = p[0]-c[0], dz = p[2]-c[1]; return [c[0] + dx*co + dz*s, p[1], c[1] - dx*s + dz*co]; },
    /** Deterministic pseudo-noise in [-1,1] from a 2D point (for knapped stone, jagged edges). */
    hash2(x, y) { const s = Math.sin(x*127.1 + y*311.7) * 43758.5453; return (s - Math.floor(s))*2 - 1; },
  };

  global.LPK = K;
})(window);
