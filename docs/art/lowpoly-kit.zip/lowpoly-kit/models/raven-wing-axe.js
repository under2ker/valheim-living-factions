/*
 * Raven's Wing («Воронье Крыло», Hrafnvængr) — Raven Clan. Long two-handed Dane axe:
 * thin crescent blade of blued pattern-welded steel with an etched silver feather,
 * a raven-beak hook on the back, silver-banded black ash haft, three raven feathers on a cord.
 * Silhouette cue: the tallest, slimmest weapon of the set — reach, not mass.
 */
(function (global) {
  'use strict';
  const { bez, canvasTex, noiseFill } = LP;
  const K = LPK;

  function build() {
    const rnd = LP.rng(101);
    const sc = new LP.Scene();
    const { X, Y, S } = K.space(242, 520);

    // ---------------- outlines (svg units)
    const blade = [[226,100],[190,128],
      ...bez([190,128],[118,126],[76,72],[58,8],4),     // upper horn sweeping up
      ...bez([58,8],[20,100],[16,230],[54,330],6),       // long crescent edge
      ...bez([54,330],[74,236],[128,180],[190,176],4),  // lower horn back to the thin neck
      [226,190]];
    const beak = [[264,104],[300,98],[336,108],[364,134],[374,176],[358,162],[334,146],[300,150],[264,184]];
    const BX0 = 16, BX1 = 226, BY0 = 8, BY1 = 330;

    // ---------------- textures
    const bladeTex = canvasTex(80, 112, (x, w, h) => {
      noiseFill(x, w, h, [52,60,76], 10, rnd);
      // pattern welding: wavy bands
      for (let j = -10; j < h + 10; j += 5) {
        x.strokeStyle = rnd() < .5 ? 'rgba(120,138,170,.35)' : 'rgba(18,22,30,.35)'; x.lineWidth = 1.5; x.beginPath();
        for (let i = 0; i <= w; i += 2) { const yy = j + Math.sin(i*.22 + j*.4)*2.2 + i*.18; i ? x.lineTo(i, yy) : x.moveTo(i, yy); }
        x.stroke();
      }
      const sx = v => (v - BX0) / (BX1 - BX0) * w, sy = v => (v - BY0) / (BY1 - BY0) * h;
      const edge = () => { x.beginPath(); x.moveTo(sx(58), sy(8)); x.bezierCurveTo(sx(20), sy(100), sx(16), sy(230), sx(54), sy(330)); };
      x.lineCap = 'round';
      edge(); x.strokeStyle = '#1c2029'; x.lineWidth = 15; x.stroke();
      edge(); x.strokeStyle = '#8e9bb0'; x.lineWidth = 12; x.stroke();
      edge(); x.strokeStyle = '#cfd6e2'; x.lineWidth = 6;  x.stroke();
      edge(); x.strokeStyle = '#f4f7fb'; x.lineWidth = 2;  x.stroke();
      // etched silver feather, diagonal across the blade
      const fx0 = sx(192), fx1 = sx(70), fy0 = sy(150), fy1 = sy(186);
      x.strokeStyle = '#d9dee8'; x.lineWidth = 1.2; x.beginPath(); x.moveTo(fx0, fy0); x.lineTo(fx1, fy1); x.stroke();
      for (let t = .12; t < .95; t += .07) {
        const px = fx0 + (fx1 - fx0)*t, py = fy0 + (fy1 - fy0)*t, len = 9*Math.sin(t*Math.PI) + 2;
        x.strokeStyle = 'rgba(205,214,228,.85)'; x.lineWidth = 1;
        x.beginPath(); x.moveTo(px, py); x.lineTo(px + len*.55, py - len*.8); x.stroke();
        x.beginPath(); x.moveTo(px, py); x.lineTo(px + len*.55, py + len*.8); x.stroke();
      }
    });
    const steelTex = K.metal(rnd, [46,52,64], { grain: 12 });
    const silverTex = K.metal(rnd, [186,192,200], { w: 16, h: 16, grain: 22, light: .2, draw: (x, w, h) => {
      x.fillStyle = 'rgba(255,255,255,.4)'; x.fillRect(0, 0, w, 2); x.fillStyle = 'rgba(40,44,52,.45)'; x.fillRect(0, h-2, w, 2); } });
    const ashTex = K.wood(rnd, [52,36,28], { streaks: 20 });
    const gripTex = K.wrap(rnd, [34,30,32], { pitch: 5, draw: (x, w, h) => {
      x.fillStyle = 'rgba(200,206,216,.9)';                                        // silver wire spiral
      for (let k = -4; k < h/10 + 4; k++) for (let i = 0; i < w; i++) x.fillRect(i, Math.floor(k*10 + i*.8), 1, 1); } });
    const featherTex = canvasTex(16, 48, (x, w, h) => {
      noiseFill(x, w, h, [22,24,32], 8, rnd);
      for (let j = 0; j < h; j += 2) {                                              // barbs with blue sheen
        x.fillStyle = j % 4 ? 'rgba(70,92,150,.55)' : 'rgba(0,0,0,.45)';
        for (let i = 0; i < w/2; i++) { x.fillRect(w/2 - 1 - i, j + Math.floor(i*.5), 1, 1); x.fillRect(w/2 + i, j + Math.floor(i*.5), 1, 1); }
      }
      x.fillStyle = '#7d8290'; x.fillRect(w/2 - 1, 0, 2, h);                       // rachis
    });
    const cordTex = K.wrap(rnd, [40,30,26], { w: 8, h: 32, pitch: 3, slope: 0 });

    // ---------------- geometry
    sc.prism(sc.mesh(ashTex, .08, 8, 'haft'), 0, 0, Y(990), Y(70), .036, .041, 8, .2, 2);
    sc.prism(sc.mesh(gripTex, .3, 14, 'grip'), 0, 0, Y(962), Y(720), .044, .044, 8, .2, 4);
    const silver = sc.mesh(silverTex, .85, 40, 'silver_fittings');
    for (const y of [330, 640, 716]) sc.prism(silver, 0, 0, Y(y + 9), Y(y), .049, .049, 8, .2);
    sc.lathe(silver, [[.0,Y(1010)],[.03,Y(1006)],[.05,Y(992)],[.046,Y(966)]], 8);                 // pommel cap

    const bx0 = X(BX0), bx1 = X(BX1), by0 = Y(BY1), by1 = Y(BY0);
    sc.extrude(sc.mesh(bladeTex, .8, 36, 'blade'), blade.map(p => S(p[0], p[1])),
      p => { const t = (p[0] - bx0) / (X(222) - bx0); return .0025 + .022 * Math.max(0, Math.min(1, t)) ** 1.6; },
      p => [(p[0] - bx0) / (bx1 - bx0), (p[1] - by0) / (by1 - by0)]);
    const steel = sc.mesh(steelTex, .6, 26, 'socket');
    sc.box(steel, X(218), X(266), Y(206), Y(84), -.042, .042);
    sc.extrude(steel, beak.map(p => S(p[0], p[1])), p => .03 - .022 * Math.max(0, (p[0] - X(264)) / (X(374) - X(264))), p => [p[0]*3, p[1]*3]);
    sc.box(silver, X(212), X(272), Y(98), Y(86), -.048, .048);
    sc.box(silver, X(212), X(272), Y(206), Y(194), -.048, .048);

    // cord + three feathers
    const cord = sc.mesh(cordTex, .05, 4, 'cord');
    const knot = [X(226), Y(300), .06];
    sc.tube(cord, [[X(236),Y(206),.045],[X(232),Y(240),.06],[X(228),Y(275),.065],knot], [.007,.007,.007,.007], 5, 0, .15, rnd);
    const fm = sc.mesh(featherTex, .25, 18, 'feathers');
    [[-.62, .44, .1], [-.15, .52, .5], [.32, .40, -.45]].forEach(([ang, L, yaw]) => {
      const f0 = sc.mark(fm), wv = .058;
      const shape = [[0,0],[wv*.5,-L*.15],[wv,-L*.45],[wv*.8,-L*.75],[wv*.25,-L*.97],[0,-L],[-wv*.3,-L*.9],[-wv*.85,-L*.6],[-wv*.9,-L*.3],[-wv*.45,-L*.1]];
      sc.extrude(fm, shape, () => .004, p => [(p[0] + wv) / (2*wv), 1 + p[1] / L]);
      sc.transform(fm, f0, p => { let q = K.rotZ(p, ang); q = K.rotY(q, yaw); return [q[0] + knot[0], q[1] + knot[1], q[2] + knot[2]]; });
    });
    sc.prism(silver, knot[0], knot[2], knot[1] - .02, knot[1] + .02, .016, .016, 6);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['raven-wing-axe'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -30, ry: 18, rx: 8, dist: 6.4, pivot: [.24, -.1] },
      icon: { w: 512, h: 512, rz: -42, ry: 24, rx: 8, dist: 5.9, pivot: [.24, -.1], offset: [-.2, -.05] },
    },
  };
})(window);
