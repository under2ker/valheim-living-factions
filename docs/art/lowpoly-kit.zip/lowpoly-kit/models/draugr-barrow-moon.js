/*
 * Barrow Moon («Курганная Луна», Haugmáni) — Draugr Court. An ancient crescent axe taken
 * from a drowned barrow: a moon-shaped blade with both horns curling back, chipped and eaten
 * by rust and verdigris; a green-bronze collar; a blackened haft bound by a rusted iron spiral;
 * rotting burial cloth; a skull pommel whose eyes — and the collar gem — smoulder red.
 * Silhouette cue: the closed crescent and hanging rags — old, dead, still hungry.
 */
(function (global) {
  'use strict';
  const { bez, canvasTex, noiseFill } = LP;
  const K = LPK;

  function build() {
    const rnd = LP.rng(606);
    const sc = new LP.Scene();
    const { X, Y, S } = K.space(242, 380);

    // outer edge: one big arc sampled coarsely, three chips knocked inward
    const outer = bez([196,18],[24,-14],[24,332],[196,300],12).map(([x, y], i) => [3, 6, 9].includes(i) ? [x + 9, y + (i < 6 ? 3 : -3)] : [x, y]);
    const blade = [[226,132],[190,128],[132,118],[140,80],[168,42], ...outer, [168,276],[140,238],[132,198],[190,190],[226,186]];
    const BX0 = 60, BX1 = 226, BY0 = 4, BY1 = 314;

    const bladeTex = canvasTex(80, 112, (x, w, h) => {
      noiseFill(x, w, h, [88,82,72], 18, rnd);
      for (let i = 0; i < 70; i++) { x.fillStyle = 'rgba(132,70,32,.55)'; x.beginPath(); x.ellipse(rnd()*w, rnd()*h, 1 + rnd()*5, 1 + rnd()*3, rnd()*3, 0, 6.283); x.fill(); }
      for (let i = 0; i < 26; i++) { x.fillStyle = 'rgba(72,128,104,.5)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1 + Math.floor(rnd()*2), 3 + Math.floor(rnd()*8)); } // verdigris runs
      for (let i = 0; i < 50; i++) { x.fillStyle = 'rgba(16,14,12,.7)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1, 1); }            // pits
      const sx = v => (v - BX0) / (BX1 - BX0) * w, sy = v => (v - BY0) / (BY1 - BY0) * h;
      x.beginPath(); outer.forEach((p, i) => i ? x.lineTo(sx(p[0]), sy(p[1])) : x.moveTo(sx(p[0]), sy(p[1])));
      x.strokeStyle = '#5f5a52'; x.lineWidth = 8; x.stroke(); x.setLineDash([5, 3, 2, 4]); x.strokeStyle = '#b8b4a8'; x.lineWidth = 2.5; x.stroke(); x.setLineDash([]);
      // worn barrow knotwork ring
      const cx = sx(102), cy = sy(160);
      x.strokeStyle = 'rgba(40,36,30,.7)'; x.lineWidth = 1.6;
      for (let k = 0; k < 3; k++) { x.beginPath(); x.ellipse(cx + Math.cos(k*2.09)*5, cy + Math.sin(k*2.09)*5, 10, 6, k*2.09, 0, 6.283); x.stroke(); }
    });
    const verdigrisTex = K.metal(rnd, [92,128,104], { w: 16, h: 16, grain: 26, rust: 10, draw: (x, w, h) => { x.fillStyle = 'rgba(150,110,52,.5)'; x.fillRect(0, 0, w, 3); } });
    const rotTex = K.wood(rnd, [46,42,36], { w: 24, h: 128, grain: 18, streaks: 26 });
    const strapTex = K.metal(rnd, [96,62,40], { w: 8, h: 32, grain: 24, rust: 20 });
    const boneTex = K.metal(rnd, [200,190,160], { w: 16, h: 16, grain: 18, dark: .12, draw: (x) => { x.fillStyle = 'rgba(90,80,56,.5)'; x.fillRect(3, 9, 10, 1); } });
    const clothTex = K.metal(rnd, [92,98,80], { w: 16, h: 48, grain: 26, blotches: 40, draw: (x, w, h) => {
      for (let j = 0; j < h; j += 2) { x.fillStyle = 'rgba(0,0,0,.12)'; x.fillRect(0, j, w, 1); }
      for (let i = 0; i < 10; i++) { x.fillStyle = 'rgba(20,22,16,.85)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1 + Math.floor(rnd()*3), 1 + Math.floor(rnd()*3)); } } });
    const emberTex = canvasTex(8, 8, (x, w, h) => { noiseFill(x, w, h, [255,84,40], 50, rnd); x.fillStyle = '#ffd08a'; x.fillRect(3, 3, 2, 2); });

    // haft + rusted spiral strap
    sc.prism(sc.mesh(rotTex, .05, 6, 'haft'), 0, 0, Y(660), Y(76), .042, .046, 7, .3, 2);
    const strap = sc.mesh(strapTex, .3, 12, 'iron_spiral');
    const hel = []; for (let i = 0; i <= 120; i++) { const t = i/120, a = t*Math.PI*2*6; hel.push([Math.cos(a)*.05, Y(640) + t*(Y(230) - Y(640)), Math.sin(a)*.05]); }
    sc.tube(strap, hel, hel.map(() => .011), 4, 0, .1, rnd);

    // crescent blade
    const bx0 = X(BX0), bx1 = X(BX1), by0 = Y(BY1), by1 = Y(BY0);
    const cres = sc.mesh(bladeTex, .35, 14, 'crescent');
    sc.extrude(cres, blade.map(p => S(p[0], p[1])),
      p => { const t = Math.max(0, Math.min(1, (p[0] - X(70)) / (X(226) - X(70)))); return .004 + .022*t + .002*K.hash2(p[0]*11, p[1]*11); },
      p => [(p[0] - bx0) / (bx1 - bx0), (p[1] - by0) / (by1 - by0)]);
    const c0 = S(226, 158);
    sc.transform(cres, 0, p => [c0[0] + (p[0] - c0[0])*1.25, c0[1] + (p[1] - c0[1])*1.25, p[2]*1.1]);   // scale the moon up around the neck
    const bronze = sc.mesh(verdigrisTex, .4, 16, 'barrow_collar');
    sc.lathe(bronze, [[.05,Y(232)],[.074,Y(220)],[.068,Y(196)],[.06,Y(120)],[.072,Y(96)],[.06,Y(76)],[.03,Y(62)],[0,Y(58)]], 7);
    // smouldering gem in the collar (both faces)
    const ember = sc.mesh(emberTex, 0, 1, 'embers', 1);
    for (const z of [.07, -.07]) { const m0 = sc.mark(ember); sc.lathe(ember, [[0,-.026],[.024,0],[0,.026]], 4); sc.transform(ember, m0, p => [p[0], p[1] + Y(158), p[2]*.4 + z]); }

    // skull pommel with glowing eyes
    const bone = sc.mesh(boneTex, .25, 12, 'skull');
    sc.lathe(bone, [[.03,Y(656)],[.06,Y(666)],[.082,Y(690)],[.086,Y(716)],[.07,Y(740)],[.05,Y(748)],[.04,Y(758)],[.032,Y(770)],[0,Y(774)]], 7);
    for (const s of [-1, 1]) sc.box(ember, s*.032 - .014, s*.032 + .014, Y(712), Y(700), .068, .084);

    // rotting burial cloth from the collar
    const cloth = sc.mesh(clothTex, .02, 4, 'burial_cloth');
    sc.ribbon(cloth, [[.05,Y(226),.07],[.06,Y(270),.09],[.045,Y(320),.1],[.06,Y(372),.095],[.05,Y(410),.09]], [.07,.064,.05,.038,.004], [1,0,.2]);
    sc.ribbon(cloth, [[-.01,Y(226),.075],[-.03,Y(262),.085],[-.02,Y(300),.09],[-.035,Y(330),.085]], [.05,.044,.03,.004], [1,0,-.2]);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['draugr-barrow-moon'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -30, ry: 22, rx: 8, dist: 4.8, pivot: [.22, -.04] },
      icon: { w: 512, h: 512, rz: -42, ry: 22, rx: 8, dist: 4.5, pivot: [.22, -.04], offset: [-.14, -.08] },
    },
  };
})(window);
