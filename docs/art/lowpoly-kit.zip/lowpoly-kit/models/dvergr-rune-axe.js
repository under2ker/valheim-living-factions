/*
 * Runebrand («Рунная Двусечка», Rúnbrandr) — Dvergr Hold. A short, heavy double-bitted axe
 * of dark Mistlands alloy: two angular bits with crisp facets, copper fittings, inlaid rune
 * channels that glow cold blue, a diamond-section haft and a glowing crystal in a copper claw.
 * Silhouette cue: perfect symmetry and straight lines — engineered, not forged by eye.
 */
(function (global) {
  'use strict';
  const { canvasTex, noiseFill } = LP;
  const K = LPK;

  function build() {
    const rnd = LP.rng(404);
    const sc = new LP.Scene();
    const { X, Y, S } = K.space(242, 360);

    const bitL = [[226,108],[184,118],[124,66],[62,52],[38,150],[62,248],[124,234],[184,182],[226,192]];
    const bitR = bitL.map(([x, y]) => [484 - x, y]).reverse();
    const BX0 = 38, BX1 = 446, BY0 = 52, BY1 = 248;

    const bladeTex = canvasTex(128, 64, (x, w, h) => {
      noiseFill(x, w, h, [40,44,56], 10, rnd);
      for (let i = 0; i < 160; i++) { x.fillStyle = rnd() < .5 ? 'rgba(0,0,0,.22)' : 'rgba(150,170,210,.1)';
        x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2 + Math.floor(rnd()*3), 2); }
      const sx = v => (v - BX0) / (BX1 - BX0) * w, sy = v => (v - BY0) / (BY1 - BY0) * h;
      // honed faceted edges (both bits)
      for (const bit of [bitL, bitR]) {
        x.beginPath(); [bit[2], bit[3], bit[4], bit[5], bit[6]].forEach((p, i) => i ? x.lineTo(sx(p[0]), sy(p[1])) : x.moveTo(sx(p[0]), sy(p[1])));
        x.lineJoin = 'miter'; x.strokeStyle = '#59627a'; x.lineWidth = 9; x.stroke(); x.strokeStyle = '#a9b6cf'; x.lineWidth = 4; x.stroke(); x.strokeStyle = '#e6eefc'; x.lineWidth = 1.2; x.stroke();
      }
      // copper inlay frame near the socket
      x.strokeStyle = '#b8643a'; x.lineWidth = 1.5;
      for (const s of [-1, 1]) { x.beginPath(); x.moveTo(sx(242 + s*60), sy(96)); x.lineTo(sx(242 + s*60), sy(204)); x.stroke(); }
    });
    const darkTex = K.metal(rnd, [44,48,60], { grain: 10 });
    const copperTex = K.metal(rnd, [184,100,58], { w: 16, h: 16, grain: 22, light: .2, draw: (x, w, h) => {
      x.fillStyle = 'rgba(255,190,140,.4)'; x.fillRect(0, 0, w, 2); x.fillStyle = 'rgba(60,24,10,.45)'; x.fillRect(0, h-2, w, 2);
      x.fillStyle = 'rgba(70,150,120,.45)'; for (let i = 0; i < 6; i++) x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1, 1); } });
    const glowTex = canvasTex(8, 8, (x, w, h) => { noiseFill(x, w, h, [96,206,255], 30, rnd); });
    const crystalTex = canvasTex(8, 16, (x, w, h) => { noiseFill(x, w, h, [120,214,255], 40, rnd); x.fillStyle = 'rgba(255,255,255,.7)'; x.fillRect(2, 2, 2, 5); });
    const haftTex = K.wood(rnd, [54,38,32], { w: 16, h: 96, streaks: 10 });
    const gripTex = K.wrap(rnd, [40,36,40], { pitch: 8, slope: 0, draw: (x, w, h) => {
      x.fillStyle = '#c87a46'; for (let j = 3; j < h; j += 8) for (let i = 2; i < w; i += 8) x.fillRect(i, j, 2, 2); } });

    // haft: diamond section, copper bands, studded grip
    sc.prism(sc.mesh(haftTex, .15, 10, 'haft'), 0, 0, Y(640), Y(90), .046, .046, 4, Math.PI/4, 2);
    sc.prism(sc.mesh(gripTex, .3, 14, 'grip'), 0, 0, Y(616), Y(452), .054, .054, 4, Math.PI/4, 2);
    const copper = sc.mesh(copperTex, .75, 30, 'copper_fittings');
    for (const y of [300, 418, 452, 616]) sc.prism(copper, 0, 0, Y(y + 10), Y(y), .062, .062, 6, 0);
    // pommel: copper claw + glowing crystal
    sc.lathe(copper, [[.062,Y(626)],[.07,Y(640)],[.05,Y(656)]], 6);
    for (let i = 0; i < 3; i++) { const a = i/3*Math.PI*2;
      sc.tube(copper, [[Math.cos(a)*.05,Y(652),Math.sin(a)*.05],[Math.cos(a)*.075,Y(690),Math.sin(a)*.075],[Math.cos(a)*.04,Y(726),Math.sin(a)*.04]], [.014,.011,.004], 4, 0, 0, rnd); }
    sc.lathe(sc.mesh(crystalTex, 0, 1, 'crystal', 1), [[0,Y(652)],[.052,Y(690)],[0,Y(740)]], 6);

    // head: two bits, octagonal copper sleeve, top spike
    const bx0 = X(BX0), bx1 = X(BX1), by0 = Y(BY1), by1 = Y(BY0);
    const th = p => { const t = Math.max(0, Math.min(1, 1 - (Math.abs(p[0]) - X(270)) / (X(446) - X(270)))); return .004 + .03*t**1.2; };
    const uv = p => [(p[0] - bx0) / (bx1 - bx0), (p[1] - by0) / (by1 - by0)];
    const blade = sc.mesh(bladeTex, .7, 34, 'bits');
    sc.extrude(blade, bitL.map(p => S(p[0], p[1])), th, uv);
    sc.extrude(blade, bitR.map(p => S(p[0], p[1])), th, uv);
    sc.lathe(copper, [[.064,Y(208)],[.08,Y(198)],[.074,Y(178)],[.07,Y(122)],[.078,Y(104)],[.06,Y(92)]], 8, 0, 0, Math.PI/8);
    sc.lathe(sc.mesh(darkTex, .7, 30, 'spike'), [[.05,Y(92)],[.04,Y(70)],[0,Y(-6)]], 4, 0, 0, Math.PI/4);

    // glowing rune channels on both faces of both bits + two rings on the sleeve
    const glow = sc.mesh(glowTex, 0, 1, 'rune_glow', 1);
    const channel = (pts) => [-1, 1].forEach(side => [1, -1].forEach(face => {
      const pp = pts.map(([sx0, sy0]) => { const xx = side < 0 ? sx0 : 484 - sx0; const p = S(xx, sy0); return [p[0], p[1], face*(th(p) + .002)]; });
      sc.tube(glow, pp, pp.map(() => .0075), 4, 0, 0, rnd);
    }));
    channel([[82,74],[60,150],[82,228]]);                                  // edge-following channel
    channel([[150,112],[130,140],[152,160],[132,188]]);                    // rune: zigzag
    channel([[170,128],[170,172]]);
    for (const y of [186, 116]) sc.lathe(glow, [[.077,Y(y + 4)],[.077,Y(y - 4)]], 8, 0, 0, Math.PI/8);
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['dvergr-rune-axe'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -30, ry: 22, rx: 8, dist: 5.0, pivot: [0, -.1] },
      icon: { w: 512, h: 512, rz: -40, ry: 22, rx: 8, dist: 4.7, pivot: [0, -.1], offset: [0, -.02] },
    },
  };
})(window);
