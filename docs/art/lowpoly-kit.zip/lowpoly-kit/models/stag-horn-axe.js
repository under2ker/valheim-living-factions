/*
 * Stag's Horn («Рог Оленя», Hjartarhorn) — Stag Clan, the merchants. A ceremonial one-hander:
 * the haft is a whole stag antler (burr at the base, three tines), the head a polished bronze
 * fan blade stamped with a merchant's seal, a round balance knob on the back, and two silver
 * trade coins hanging on a chain.
 * Silhouette cue: branching haft + warm gold head — wealth, not war.
 */
(function (global) {
  'use strict';
  const { bez, canvasTex, noiseFill } = LP;
  const K = LPK;

  function build() {
    const rnd = LP.rng(202);
    const sc = new LP.Scene();
    const { X, Y, S } = K.space(242, 380);

    const blade = [[226,104],[184,120],
      ...bez([184,120],[150,110],[120,70],[98,34],3),
      ...bez([98,34],[50,90],[50,210],[98,266],6),        // broad fan edge
      ...bez([98,266],[120,230],[150,190],[184,180],3),
      [226,196]];
    const BX0 = 50, BX1 = 226, BY0 = 34, BY1 = 266;

    // ---------------- textures
    const bladeTex = canvasTex(80, 104, (x, w, h) => {
      noiseFill(x, w, h, [182,124,56], 16, rnd);
      for (let i = 0; i < 160; i++) { x.fillStyle = rnd() < .5 ? 'rgba(90,50,16,.2)' : 'rgba(255,220,150,.16)';
        x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 2 + Math.floor(rnd()*3), 2 + Math.floor(rnd()*2)); }
      const sx = v => (v - BX0) / (BX1 - BX0) * w, sy = v => (v - BY0) / (BY1 - BY0) * h;
      const edge = () => { x.beginPath(); x.moveTo(sx(98), sy(34)); x.bezierCurveTo(sx(50), sy(90), sx(50), sy(210), sx(98), sy(266)); };
      x.lineCap = 'round';
      edge(); x.strokeStyle = '#7a4a1c'; x.lineWidth = 14; x.stroke();
      edge(); x.strokeStyle = '#e2b56a'; x.lineWidth = 10; x.stroke();
      edge(); x.strokeStyle = '#fff0c8'; x.lineWidth = 3; x.stroke();
      // merchant's seal: stamped coin with rim dots and a scale (balance) mark
      const cx = sx(130), cy = sy(150), r = 15;
      x.strokeStyle = '#6e3f14'; x.lineWidth = 2; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI*2); x.stroke();
      x.strokeStyle = '#f2cf8a'; x.lineWidth = 1; x.beginPath(); x.arc(cx, cy, r - 2, 0, Math.PI*2); x.stroke();
      x.fillStyle = '#6e3f14'; for (let a = 0; a < 16; a++) x.fillRect(Math.round(cx + Math.cos(a/16*6.283)*(r-5)), Math.round(cy + Math.sin(a/16*6.283)*(r-5)), 1, 1);
      x.strokeStyle = '#5a3210'; x.lineWidth = 1.4; x.beginPath();
      x.moveTo(cx, cy - 7); x.lineTo(cx, cy + 6); x.moveTo(cx - 7, cy - 4); x.lineTo(cx + 7, cy - 4);
      x.moveTo(cx - 7, cy - 4); x.lineTo(cx - 9, cy + 1); x.lineTo(cx - 5, cy + 1); x.lineTo(cx - 7, cy - 4);
      x.moveTo(cx + 7, cy - 4); x.lineTo(cx + 5, cy + 1); x.lineTo(cx + 9, cy + 1); x.lineTo(cx + 7, cy - 4); x.stroke();
      // scroll-work leaves above and below the seal
      x.strokeStyle = 'rgba(96,56,20,.85)'; x.lineWidth = 1;
      for (const s of [-1, 1]) { x.beginPath(); x.moveTo(sx(184), sy(150) + s*20); x.bezierCurveTo(sx(160), sy(150) + s*34, sx(120), sy(150) + s*40, sx(100), sy(150) + s*30); x.stroke(); }
    });
    const antlerTex = K.wood(rnd, [214,196,164], { w: 24, h: 128, grain: 14, streaks: 26, draw: (x, w, h) => {
      for (let i = 0; i < 40; i++) { x.fillStyle = 'rgba(110,80,50,.35)'; x.fillRect(Math.floor(rnd()*w), Math.floor(rnd()*h), 1, 2 + Math.floor(rnd()*3)); }
      x.fillStyle = 'rgba(120,88,56,.35)'; x.fillRect(0, h*.82, w, h*.18); } });
    const tipTex = K.flat(rnd, [236,226,204], 10, 8, 16);
    const bronzeTex = K.metal(rnd, [176,116,46], { w: 16, h: 16, grain: 24, light: .2, draw: (x, w, h) => {
      x.fillStyle = 'rgba(255,214,140,.4)'; x.fillRect(0, 0, w, 3); x.fillStyle = 'rgba(70,36,10,.4)'; x.fillRect(0, h-3, w, 3); } });
    const gripTex = K.wrap(rnd, [46,84,52], { pitch: 6, draw: (x, w, h) => {      // green-dyed merchant leather + gold stitch
      x.fillStyle = 'rgba(232,190,104,.9)'; for (let j = 3; j < h; j += 6) for (let i = 0; i < w; i += 4) x.fillRect(i, Math.floor(j + i*.35), 2, 1); } });
    const silverTex = K.metal(rnd, [214,218,224], { w: 16, h: 16, grain: 22, light: .25 });   // caps sample the centre: keep it plain
    const chainTex = K.metal(rnd, [150,154,160], { w: 8, h: 16, grain: 30 });

    // ---------------- antler haft
    const antler = sc.mesh(antlerTex, .25, 14, 'antler_haft');
    const path = [], radii = [], N = 12;
    for (let k = 0; k <= N; k++) { const t = k / N; path.push([.03*Math.sin(t*3.2), Y(690) + t*(Y(66) - Y(690)), .012*Math.sin(t*5)]); radii.push(.056 - .018*t); }
    sc.tube(antler, path, radii, 7, .3, .1, rnd);
    sc.lathe(antler, [[0,Y(706)],[.05,Y(700)],[.058,Y(690)]], 7);                                  // base
    sc.lathe(antler, [[.04,Y(82)],[.036,Y(70)],[.024,Y(58)],[0,Y(52)]], 7);                        // rounded top above the head
    const burr = sc.mesh(antlerTex, .2, 10, 'antler_burr');
    sc.tube(burr, [[.0,Y(684),0],[.0,Y(672),0]], [.088,.086], 11, 0, .22, rnd);
    // tines: brow tine forward-down, back tine, hook tine under the head
    const tines = sc.mesh(tipTex, .3, 16, 'antler_tines');
    const tine = (pts, r0) => sc.tube(tines, pts, pts.map((_, i) => r0 * (1 - i/(pts.length - 1)) + .003), 6, .2, .08, rnd);
    tine([[X(242),Y(652),.0],[X(220),Y(672),.012],[X(198),Y(704),.02],[X(186),Y(744),.02]], .03);
    tine([[X(242),Y(432),.0],[X(268),Y(418),-.01],[X(292),Y(392),-.016],[X(304),Y(356),-.016]], .028);
    tine([[X(242),Y(262),.0],[X(268),Y(250),.01],[X(286),Y(226),.014],[X(292),Y(196),.012]], .025);

    sc.prism(sc.mesh(gripTex, .1, 8, 'grip'), .015, .005, Y(640), Y(470), .058, .055, 8, .2, 2.6);
    const bronze = sc.mesh(bronzeTex, .7, 30, 'bronze_fittings');
    sc.prism(bronze, .015, .005, Y(648), Y(638), .066, .066, 8, .2); sc.prism(bronze, .013, .005, Y(474), Y(464), .063, .063, 8, .2);

    // ---------------- bronze head
    const bx0 = X(BX0), bx1 = X(BX1), by0 = Y(BY1), by1 = Y(BY0);
    sc.extrude(sc.mesh(bladeTex, .95, 22, 'blade'), blade.map(p => S(p[0], p[1])),
      p => { const t = (p[0] - bx0) / (X(222) - bx0); return .004 + .024 * Math.max(0, Math.min(1, t)) ** 1.3; },
      p => [(p[0] - bx0) / (bx1 - bx0), (p[1] - by0) / (by1 - by0)]);
    sc.lathe(bronze, [[.052,Y(212)],[.072,Y(204)],[.066,Y(184)],[.062,Y(118)],[.07,Y(100)],[.058,Y(88)],[.046,Y(84)]], 8, 0, 0, Math.PI/8);
    // balance knob on the back (a lathe turned to point +X)
    const k0 = sc.mark(bronze);
    sc.lathe(bronze, [[0,0],[.03,.004],[.05,.03],[.056,.06],[.045,.09],[.025,.105],[0,.11]], 8);
    sc.lathe(bronze, [[.034,-.02],[.03,.0]], 8);
    sc.transform(bronze, k0, p => { const q = K.rotZ(p, -Math.PI/2); return [q[0] + X(262), q[1] + Y(150), q[2]]; });

    // ---------------- two trade coins on a chain
    const chain = sc.mesh(chainTex, .6, 24, 'chain');
    const silver = sc.mesh(silverTex, .8, 36, 'coins');
    [[X(236), Y(250), .07, .0], [X(222), Y(300), .065, .5]].forEach(([cx, cy, cz, yaw]) => {
      sc.tube(chain, [[X(238),Y(208),.05],[cx + .005, (Y(208) + cy)/2, cz],[cx, cy + .05, cz]], [.006,.006,.006], 4, 0, 0, rnd);
      const c0 = sc.mark(silver);
      sc.prism(silver, 0, 0, -.007, .007, .062, .062, 10);
      sc.prism(silver, 0, 0, -.011, .011, .03, .03, 10);                               // raised boss
      sc.transform(silver, c0, p => { let q = [p[0], -p[2], p[1]]; q = K.rotY(q, yaw); return [q[0] + cx, q[1] + cy, q[2] + cz]; });
    });
    return sc;
  }

  global.LP_MODELS = global.LP_MODELS || {};
  global.LP_MODELS['stag-horn-axe'] = {
    build,
    views: {
      hero: { w: 1400, h: 1400, rz: -30, ry: 24, rx: 8, dist: 4.7, pivot: [.2, 0] },
      icon: { w: 512, h: 512, rz: -42, ry: 24, rx: 8, dist: 4.4, pivot: [.2, 0], offset: [-.15, -.1] },
    },
  };
})(window);
