/*
 * lowpoly.js — a tiny dependency-free WebGL2 engine for Valheim-style low-poly item renders.
 *
 * Classic script (no ES modules) so render.html works from file:// as well as from a server.
 * Everything lives on the global `LP` object.
 *
 *   LP.M            4x4 column-major matrix helpers (mul, persp, trans, rx, ry, rz, ident)
 *   LP.rng(seed)    seeded Park–Miller RNG; returns () => [0,1)
 *   LP.bez(...)     sample a cubic Bezier into N points (low-poly curves)
 *   LP.earcut(pts)  ear-clipping triangulation of a simple 2D polygon
 *   LP.canvasTex    draw a texture on a small <canvas> (sampled NEAREST => pixel look)
 *   LP.noiseFill    per-pixel grey/colour noise fill
 *   new LP.Scene()  collects meshes; builders: extrude, prism, box, tube
 *   LP.render(canvas, scene, opts)  draws the scene with the stylised shader
 *
 * Geometry is non-indexed (3 vertices per triangle) and flat-shaded: the fragment shader
 * derives the face normal from screen-space derivatives, so each triangle is one flat facet.
 */
(function (global) {
  'use strict';

  // ---------------------------------------------------------------- math
  const M = {
    ident() { return [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]; },
    mul(a, b) {
      const o = new Array(16);
      for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
        let s = 0; for (let k = 0; k < 4; k++) s += a[k*4+r] * b[c*4+k]; o[c*4+r] = s;
      }
      return o;
    },
    persp(fovRad, aspect, near, far) {
      const t = 1 / Math.tan(fovRad / 2);
      return [t/aspect,0,0,0, 0,t,0,0, 0,0,(far+near)/(near-far),-1, 0,0,2*far*near/(near-far),0];
    },
    trans(x, y, z) { const m = M.ident(); m[12] = x; m[13] = y; m[14] = z; return m; },
    rx(a) { const c = Math.cos(a), s = Math.sin(a); return [1,0,0,0, 0,c,s,0, 0,-s,c,0, 0,0,0,1]; },
    ry(a) { const c = Math.cos(a), s = Math.sin(a); return [c,0,-s,0, 0,1,0,0, s,0,c,0, 0,0,0,1]; },
    rz(a) { const c = Math.cos(a), s = Math.sin(a); return [c,s,0,0, -s,c,0,0, 0,0,1,0, 0,0,0,1]; },
  };

  // ---------------------------------------------------------------- random
  function rng(seed) {
    let s = seed % 2147483647; if (s <= 0) s += 2147483646;
    return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
  }

  // ---------------------------------------------------------------- 2D helpers
  /** Sample a cubic Bezier p0..p3 into n points (p0 excluded, p3 included). */
  function bez(p0, p1, p2, p3, n) {
    const o = [];
    for (let i = 1; i <= n; i++) {
      const t = i / n, u = 1 - t;
      o.push([
        u*u*u*p0[0] + 3*u*u*t*p1[0] + 3*u*t*t*p2[0] + t*t*t*p3[0],
        u*u*u*p0[1] + 3*u*u*t*p1[1] + 3*u*t*t*p2[1] + t*t*t*p3[1],
      ]);
    }
    return o;
  }

  function signedArea(p) {
    let s = 0;
    for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i+1) % p.length]; s += a[0]*b[1] - b[0]*a[1]; }
    return s / 2;
  }

  /** Ear clipping for a simple CCW polygon. Returns [[i,j,k], ...]. O(n^3), fine for < 200 points. */
  function earcut(pts) {
    const idx = pts.map((_, i) => i), out = [];
    const area = (a, b, c) => (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0]);
    const inside = (p, a, b, c) => area(a,b,p) >= 0 && area(b,c,p) >= 0 && area(c,a,p) >= 0;
    let guard = 0;
    while (idx.length > 3 && guard++ < 5000) {
      let cut = false;
      for (let i = 0; i < idx.length; i++) {
        const ia = idx[(i + idx.length - 1) % idx.length], ib = idx[i], ic = idx[(i+1) % idx.length];
        const a = pts[ia], b = pts[ib], c = pts[ic];
        if (area(a, b, c) <= 1e-9) continue;                 // reflex or degenerate
        let ok = true;
        for (const j of idx) { if (j === ia || j === ib || j === ic) continue; if (inside(pts[j], a, b, c)) { ok = false; break; } }
        if (ok) { out.push([ia, ib, ic]); idx.splice(i, 1); cut = true; break; }
      }
      if (!cut) break;                                       // self-intersecting input: give up gracefully
    }
    if (idx.length === 3) out.push(idx.slice());
    return out;
  }

  // ---------------------------------------------------------------- textures
  /** Create a w×h canvas and let `draw(ctx, w, h)` paint it. Keep sizes tiny (16–128 px). */
  function canvasTex(w, h, draw) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h); return c;
  }
  /** Fill with base colour ± amp/2 noise per pixel (same offset on all channels => grey grain). */
  function noiseFill(ctx, w, h, base, amp, rnd) {
    const d = ctx.getImageData(0, 0, w, h);
    for (let i = 0; i < w*h; i++) {
      const n = (rnd() - .5) * amp;
      d.data[i*4] = base[0] + n; d.data[i*4+1] = base[1] + n; d.data[i*4+2] = base[2] + n*1.05; d.data[i*4+3] = 255;
    }
    ctx.putImageData(d, 0, 0);
  }

  // ---------------------------------------------------------------- scene + builders
  class Scene {
    constructor() { this.meshes = []; }
    /**
     * New mesh = one draw call with one material.
     * tex: canvas; spec: specular strength 0..1; shin: Blinn-Phong exponent; name: for export.
     */
    mesh(tex, spec, shin, name, emit = 0) { const m = { name: name || ('mesh' + this.meshes.length), tex, spec, shin, emit, p: [], u: [] }; this.meshes.push(m); return m; }
    tri(m, a, b, c, ua, ub, uc) { m.p.push(...a, ...b, ...c); m.u.push(...ua, ...ub, ...uc); }
    quad(m, a, b, c, d, ua, ub, uc, ud) { this.tri(m, a, b, c, ua, ub, uc); this.tri(m, a, c, d, ua, uc, ud); }

    /**
     * Extrude a 2D outline (in the XY plane) symmetrically along Z.
     * th(p) => half-thickness at that outline point (lets you make wedges, e.g. a blade);
     * uvf(p) => [u,v] for front/back faces. Sides reuse the outline UVs.
     */
    extrude(m, pts, th, uvf, zoff = 0) {
      if (signedArea(pts) < 0) pts = pts.slice().reverse();
      for (const [a, b, c] of earcut(pts)) {
        const A = pts[a], B = pts[b], C = pts[c];
        this.tri(m, [A[0],A[1],zoff+th(A)], [B[0],B[1],zoff+th(B)], [C[0],C[1],zoff+th(C)], uvf(A), uvf(B), uvf(C));
        this.tri(m, [A[0],A[1],zoff-th(A)], [C[0],C[1],zoff-th(C)], [B[0],B[1],zoff-th(B)], uvf(A), uvf(C), uvf(B));
      }
      for (let i = 0; i < pts.length; i++) {
        const A = pts[i], B = pts[(i+1) % pts.length], ua = uvf(A), ub = uvf(B);
        this.quad(m, [A[0],A[1],zoff-th(A)], [B[0],B[1],zoff-th(B)], [B[0],B[1],zoff+th(B)], [A[0],A[1],zoff+th(A)], ua, ub, ub, ua);
      }
    }

    /** Vertical N-sided prism / frustum around (cx, cz) from y0 (radius r0) to y1 (radius r1). Capped. */
    prism(m, cx, cz, y0, y1, r0, r1, seg, rot = 0, vrep = 1) {
      for (let i = 0; i < seg; i++) {
        const a0 = rot + i/seg*Math.PI*2, a1 = rot + (i+1)/seg*Math.PI*2;
        const p = (a, y, r) => [cx + Math.cos(a)*r, y, cz + Math.sin(a)*r];
        this.quad(m, p(a0,y0,r0), p(a1,y0,r0), p(a1,y1,r1), p(a0,y1,r1), [i/seg,0], [(i+1)/seg,0], [(i+1)/seg,vrep], [i/seg,vrep]);
        this.tri(m, [cx,y1,cz], p(a1,y1,r1), p(a0,y1,r1), [.5,.5], [.5,.6], [.6,.5]);
        this.tri(m, [cx,y0,cz], p(a0,y0,r0), p(a1,y0,r0), [.5,.5], [.6,.5], [.5,.6]);
      }
    }

    /** Axis-aligned box. */
    box(m, x0, x1, y0, y1, z0, z1) {
      const v = (x, y, z) => [x, y, z];
      const f = (a, b, c, d) => this.quad(m, a, b, c, d, [0,0], [1,0], [1,1], [0,1]);
      f(v(x0,y0,z1), v(x1,y0,z1), v(x1,y1,z1), v(x0,y1,z1)); f(v(x1,y0,z0), v(x0,y0,z0), v(x0,y1,z0), v(x1,y1,z0));
      f(v(x0,y0,z0), v(x0,y0,z1), v(x0,y1,z1), v(x0,y1,z0)); f(v(x1,y0,z1), v(x1,y0,z0), v(x1,y1,z0), v(x1,y1,z1));
      f(v(x0,y1,z1), v(x1,y1,z1), v(x1,y1,z0), v(x0,y1,z0)); f(v(x0,y0,z0), v(x1,y0,z0), v(x1,y0,z1), v(x0,y0,z1));
    }

    /**
     * Tube along a 3D polyline. radii[k] per path point; seg sides; twist (rad per ring);
     * jitter: random radial noise per side (0 = smooth), drawn from rnd — good for fur/rope.
     */
    /** Lathe: revolve a profile [[radius, y], ...] (bottom→top) around the Y axis at (cx, cz). */
    lathe(m, prof, seg, cx = 0, cz = 0, rot = 0) {
      for (let k = 0; k < prof.length - 1; k++) for (let i = 0; i < seg; i++) {
        const a0 = rot + i/seg*Math.PI*2, a1 = rot + (i+1)/seg*Math.PI*2;
        const [r0, y0] = prof[k], [r1, y1] = prof[k+1];
        const p = (a, y, r) => [cx + Math.cos(a)*r, y, cz + Math.sin(a)*r];
        const v0 = k/(prof.length-1), v1 = (k+1)/(prof.length-1);
        this.quad(m, p(a0,y0,r0), p(a1,y0,r0), p(a1,y1,r1), p(a0,y1,r1), [i/seg,v0], [(i+1)/seg,v0], [(i+1)/seg,v1], [i/seg,v1]);
      }
    }

    /** Flat strip along a 3D path: each point is offset ±widths[k]/2 along `side`. For cloth, feathers, leaves. */
    ribbon(m, path, widths, side) {
      for (let k = 0; k < path.length - 1; k++) {
        const e = (c, w, s) => [c[0] + side[0]*w*s, c[1] + side[1]*w*s, c[2] + side[2]*w*s];
        const a = path[k], b = path[k+1], wa = widths[k]/2, wb = widths[k+1]/2;
        const v0 = 1 - k/(path.length-1), v1 = 1 - (k+1)/(path.length-1);
        this.quad(m, e(a,wa,-1), e(a,wa,1), e(b,wb,1), e(b,wb,-1), [0,v0], [1,v0], [1,v1], [0,v1]);
      }
    }

    /** Remember where the next geometry starts in mesh m (use with transform). */
    mark(m) { return m.p.length; }
    /** Apply f([x,y,z]) => [x,y,z] to every vertex of m added since `from` (a value returned by mark). */
    transform(m, from, f) {
      for (let i = from; i < m.p.length; i += 3) { const q = f([m.p[i], m.p[i+1], m.p[i+2]]); m.p[i] = q[0]; m.p[i+1] = q[1]; m.p[i+2] = q[2]; }
    }

    tube(m, path, radii, seg, twist = 0, jitter = 0, rnd = Math.random) {
      const rings = path.map((c, k) => {
        const n = path[Math.min(k+1, path.length-1)], pv = path[Math.max(k-1, 0)];
        const d = [n[0]-pv[0], n[1]-pv[1], n[2]-pv[2]]; const L = Math.hypot(...d); const t = d.map(v => v/L);
        let a = [0,0,1];
        let b = [t[1]*a[2]-t[2]*a[1], t[2]*a[0]-t[0]*a[2], t[0]*a[1]-t[1]*a[0]]; const bl = Math.hypot(...b); b = b.map(v => v/bl);
        a = [b[1]*t[2]-b[2]*t[1], b[2]*t[0]-b[0]*t[2], b[0]*t[1]-b[1]*t[0]];
        const jit = []; for (let i = 0; i < seg; i++) jit.push(1 - jitter + rnd()*2*jitter);
        const r = [];
        for (let i = 0; i <= seg; i++) {
          const an = i/seg*Math.PI*2 + k*twist, rr = radii[k] * jit[i % seg];
          r.push([c[0] + (Math.cos(an)*a[0] + Math.sin(an)*b[0])*rr,
                  c[1] + (Math.cos(an)*a[1] + Math.sin(an)*b[1])*rr,
                  c[2] + (Math.cos(an)*a[2] + Math.sin(an)*b[2])*rr]);
        }
        return r;
      });
      for (let k = 0; k < rings.length-1; k++) for (let i = 0; i < seg; i++) {
        const v0 = k/(rings.length-1), v1 = (k+1)/(rings.length-1);
        this.quad(m, rings[k][i], rings[k][i+1], rings[k+1][i+1], rings[k+1][i],
          [i/seg,1-v0], [(i+1)/seg,1-v0], [(i+1)/seg,1-v1], [i/seg,1-v1]);
      }
    }
  }

  // ---------------------------------------------------------------- shader
  const VS = `#version 300 es
in vec3 p; in vec2 u; uniform mat4 mvp; uniform mat4 mv; out vec3 vp; out vec2 vu;
void main(){ vp = (mv*vec4(p,1.)).xyz; vu = u; gl_Position = mvp*vec4(p,1.); }`;

  // Lighting is in VIEW space (camera at origin). Stylised: flat facets, 4-step diffuse blend,
  // hemisphere ambient, warm sun, cool rim, Reinhard-ish tone map, gamma 2.2.
  const FS = `#version 300 es
precision highp float;
in vec3 vp; in vec2 vu;
uniform sampler2D t; uniform float spec, shin, emit, emitPass;
uniform vec3 sunDir, sunCol, skyCol, groundCol, rimDir, rimCol;
uniform float steps, stepMix;
out vec4 o;
void main(){
  vec3 n = normalize(cross(dFdx(vp), dFdy(vp)));        // flat facet normal
  vec3 v = normalize(-vp); if (dot(n,v) < 0.) n = -n;    // two-sided
  vec3 alb = pow(texture(t, vu).rgb, vec3(2.2));
  vec3 L = normalize(sunDir), R = normalize(rimDir);
  vec3 amb = mix(groundCol, skyCol, n.y*.5+.5);
  float d = max(dot(n,L), 0.);
  d = mix(d, floor(d*steps+.5)/steps, stepMix);          // painterly banding
  float s = pow(max(dot(n, normalize(L+v)), 0.), shin) * spec;
  float rr = pow(1.-max(dot(n,v),0.), 3.) * max(dot(n,R)+.3, 0.);
  vec3 c = alb*(amb + sunCol*d) + sunCol*s*.9 + rimCol*rr*.8;
  c = c/(c+vec3(.85))*1.55;
  c = pow(c, vec3(1./2.2));
  c = mix(c, min(texture(t, vu).rgb*1.25 + vec3(.08), vec3(1.)), emit);   // emissive: unlit, slightly boosted
  if (emitPass > .5) c *= emit;                        // glow mask: only emissive meshes stay lit
  o = vec4(c, 1.);
}`;

  const DEFAULT_LIGHT = {
    sunDir: [-.55, .75, .62], sunCol: [1.55, 1.2, .82],
    skyCol: [.26, .30, .38], groundCol: [.14, .10, .07],
    rimDir: [.8, .15, -.6], rimCol: [.35, .45, .65],
    steps: 4, stepMix: .35,
  };

  /**
   * Render `scene` into `canvas`.
   * opts: { w, h, fov (deg), dist, rx, ry, rz (deg), pivot:[x,y] (model offset before rotation),
   *         offset:[x,y] (screen-plane offset after rotation), light:{...DEFAULT_LIGHT overrides},
   *         emitPass: true => draw a glow mask (emissive meshes lit, everything else black) }
   */
  function render(canvas, scene, opts = {}) {
    const W = opts.w || 1200, H = opts.h || 1200;
    canvas.width = W; canvas.height = H;
    const gl = canvas.getContext('webgl2', { antialias: true, alpha: true, premultipliedAlpha: false, preserveDrawingBuffer: true });
    if (!gl) throw new Error('WebGL2 unavailable');
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    const pr = gl.createProgram();
    gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(pr); gl.useProgram(pr);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);           // v=0 is the BOTTOM row of the canvas texture

    const cache = new Map();
    const glTex = c => {
      if (cache.has(c)) return cache.get(c);
      const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
      cache.set(c, t); return t;
    };
    const ap = gl.getAttribLocation(pr, 'p'), au = gl.getAttribLocation(pr, 'u');
    const draws = scene.meshes.filter(m => m.p.length).map(m => {
      const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
      const b1 = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b1); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(m.p), gl.STATIC_DRAW);
      gl.enableVertexAttribArray(ap); gl.vertexAttribPointer(ap, 3, gl.FLOAT, false, 0, 0);
      const b2 = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b2); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(m.u), gl.STATIC_DRAW);
      gl.enableVertexAttribArray(au); gl.vertexAttribPointer(au, 2, gl.FLOAT, false, 0, 0);
      return { m, vao, n: m.p.length / 3, tex: glTex(m.tex) };
    });

    const deg = Math.PI / 180;
    const pivot = opts.pivot || [0, 0], off = opts.offset || [0, 0];
    const model = M.mul(M.trans(off[0], off[1], 0),
      M.mul(M.rz((opts.rz ?? -30) * deg), M.mul(M.rx((opts.rx ?? 8) * deg), M.mul(M.ry((opts.ry ?? 28) * deg), M.trans(pivot[0], pivot[1], 0)))));
    const view = M.trans(0, 0, -(opts.dist || 5));
    const proj = M.persp((opts.fov || 30) * deg, W / H, .1, 50);
    const mv = M.mul(view, model), mvp = M.mul(proj, mv);

    gl.viewport(0, 0, W, H); gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST);
    const U = n => gl.getUniformLocation(pr, n);
    gl.uniformMatrix4fv(U('mvp'), false, new Float32Array(mvp));
    gl.uniformMatrix4fv(U('mv'), false, new Float32Array(mv));
    const light = Object.assign({}, DEFAULT_LIGHT, opts.light || {});
    for (const k of ['sunDir','sunCol','skyCol','groundCol','rimDir','rimCol']) gl.uniform3fv(U(k), light[k]);
    gl.uniform1f(U('steps'), light.steps); gl.uniform1f(U('stepMix'), light.stepMix);
    gl.uniform1i(U('t'), 0); gl.uniform1f(U('emitPass'), opts.emitPass ? 1 : 0);
    for (const d of draws) {
      gl.bindVertexArray(d.vao); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, d.tex);
      gl.uniform1f(U('spec'), d.m.spec); gl.uniform1f(U('shin'), d.m.shin); gl.uniform1f(U('emit'), d.m.emit || 0);
      gl.drawArrays(gl.TRIANGLES, 0, d.n);
    }
    gl.finish();
  }

  // ---------------------------------------------------------------- export
  /**
   * Wavefront OBJ + MTL text for the scene (one `o`/`usemtl` per mesh, textures referenced as
   * <name>.png). Triangles are emitted un-welded, which keeps the flat-shaded look in any importer.
   */
  function toOBJ(scene, base = 'model') {
    let obj = `# lowpoly.js export\nmtllib ${base}.mtl\n`, mtl = '', vi = 1;
    const texNames = new Map();
    scene.meshes.forEach(m => {
      if (!m.p.length) return;
      if (!texNames.has(m.tex)) texNames.set(m.tex, `${base}_${m.name}`);
      const tn = texNames.get(m.tex), mat = `${m.name}_mat`;
      mtl += `newmtl ${mat}\nKd 1 1 1\nKs ${m.spec} ${m.spec} ${m.spec}\nNs ${m.shin}\nKe ${m.emit||0} ${m.emit||0} ${m.emit||0}\nmap_Kd ${tn}.png${m.emit ? `\nmap_Ke ${tn}.png` : ''}\n\n`;
      obj += `o ${m.name}\nusemtl ${mat}\ns off\n`;
      for (let i = 0; i < m.p.length; i += 3) obj += `v ${m.p[i].toFixed(5)} ${m.p[i+1].toFixed(5)} ${m.p[i+2].toFixed(5)}\n`;
      for (let i = 0; i < m.u.length; i += 2) obj += `vt ${m.u[i].toFixed(5)} ${m.u[i+1].toFixed(5)}\n`;
      const n = m.p.length / 3;
      for (let i = 0; i < n; i += 3) obj += `f ${vi+i}/${vi+i} ${vi+i+1}/${vi+i+1} ${vi+i+2}/${vi+i+2}\n`;
      vi += n;
    });
    const textures = [...texNames].map(([canvas, name]) => ({ name, dataURL: canvas.toDataURL('image/png'), w: canvas.width, h: canvas.height }));
    return { obj, mtl, textures };
  }

  /** Plain JSON (positions, uvs, material params, texture name per mesh) — easiest to port to C#/Unity. */
  function toJSON(scene, base = 'model') {
    const texNames = new Map(); const meshes = [];
    scene.meshes.forEach(m => {
      if (!m.p.length) return;
      if (!texNames.has(m.tex)) texNames.set(m.tex, `${base}_${m.name}`);
      meshes.push({ name: m.name, texture: texNames.get(m.tex), spec: m.spec, shininess: m.shin, emissive: m.emit || 0,
        positions: m.p.map(v => +v.toFixed(5)), uvs: m.u.map(v => +v.toFixed(5)) });
    });
    return { format: 'lowpoly-kit/1', units: 'metres (approx.)', up: 'Y', winding: 'unspecified (render two-sided)', meshes };
  }

  global.LP = { M, rng, bez, earcut, signedArea, canvasTex, noiseFill, Scene, render, toOBJ, toJSON, DEFAULT_LIGHT };
})(window);
