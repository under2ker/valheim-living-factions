// Shared Playwright launcher. Software WebGL2 (SwiftShader) works headless with no GPU.
const path = require('path');
function loadPlaywright() {
  const tries = ['playwright', '@playwright/test', '/opt/npm-tools/node_modules/playwright'];
  for (const t of tries) { try { return require(t); } catch (_) {} }
  throw new Error('Playwright not found. Install it: npm i -D playwright && npx playwright install chromium');
}
async function openRender(hash, viewport = 2000) {
  const { chromium } = loadPlaywright();
  const browser = await chromium.launch({ args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: viewport, height: viewport } });
  page.on('pageerror', e => console.error('[page error]', e.message));
  page.on('console', m => { if (m.type() === 'error') console.error('[console]', m.text()); });
  const url = 'file://' + path.resolve(__dirname, '..', 'render.html') + '#' + hash;
  await page.goto(url);
  await page.waitForFunction(() => document.title === 'done', null, { timeout: 60000 });
  return { browser, page };
}
module.exports = { openRender };
