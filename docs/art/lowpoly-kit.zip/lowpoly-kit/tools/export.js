#!/usr/bin/env node
// Export the model geometry: OBJ + MTL + texture PNGs + a JSON mesh dump (for porting to C#/Unity).
// Usage: node tools/export.js <model> <outDir>
const fs = require('fs'), path = require('path');
const { openRender } = require('./_browser');
(async () => {
  const [, , model = 'wolf-fang-axe', outDir = 'output/export'] = process.argv;
  fs.mkdirSync(outDir, { recursive: true });
  const { browser, page } = await openRender(`model=${model}&w=64&h=64`, 256);
  const data = await page.evaluate(m => ({ ...LP.toOBJ(window.__scene, m), json: LP.toJSON(window.__scene, m) }), model);
  fs.writeFileSync(path.join(outDir, `${model}.obj`), data.obj);
  fs.writeFileSync(path.join(outDir, `${model}.mtl`), data.mtl);
  fs.writeFileSync(path.join(outDir, `${model}.json`), JSON.stringify(data.json));
  for (const t of data.textures) fs.writeFileSync(path.join(outDir, `${t.name}.png`), Buffer.from(t.dataURL.split(',')[1], 'base64'));
  const tris = data.json.meshes.reduce((s, m) => s + m.positions.length / 9, 0);
  console.log(`wrote ${outDir}: ${data.json.meshes.length} meshes, ${tris} triangles, ${data.textures.length} textures`);
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
