#!/usr/bin/env python3
"""Post-process raw renders: optional glow (bloom) from an emissive mask, crop, drop shadow, resize.

Usage:
  python3 tools/postprocess.py hero raw.png out.png [--glow mask.png]
  python3 tools/postprocess.py icon raw.png out.png [--glow mask.png] [--size 256]
The mask comes from render.html#...&pass=emit (same view, same size). Requires Pillow.
"""
import argparse
from PIL import Image, ImageChops, ImageFilter


def add_glow(im, mask_path, radius):
    """Blur the emissive mask and add it on top; the halo also extends the alpha so it shows on any background."""
    m = Image.open(mask_path).convert('RGBA')
    rgb = Image.new('RGB', m.size, (0, 0, 0))
    rgb.paste(m.convert('RGB'), (0, 0), m.split()[3])
    if not rgb.getbbox():
        return im  # nothing emissive
    halo = ImageChops.add(rgb.filter(ImageFilter.GaussianBlur(radius)), rgb.filter(ImageFilter.GaussianBlur(radius * 3)))
    out = Image.new('RGBA', im.size, (0, 0, 0, 0))
    a = halo.convert('L').point(lambda v: min(255, int(v * 1.6)))
    out.paste(halo, (0, 0), a)                      # halo layer under the item
    out.alpha_composite(im)
    lit = ImageChops.add(out.convert('RGB'), halo.point(lambda v: int(v * .55)))  # and a little bloom over it
    lit = lit.convert('RGBA'); lit.putalpha(out.split()[3])
    return lit


def shadow(im, off, blur, opacity):
    a = im.split()[3]
    sh = Image.new('RGBA', im.size, (0, 0, 0, 0))
    sh.paste(Image.new('RGBA', im.size, (8, 6, 4, 255)), (off, off), a)
    sh = sh.filter(ImageFilter.GaussianBlur(blur))
    sh.putalpha(sh.split()[3].point(lambda v: int(v * opacity)))
    sh.alpha_composite(im)
    return sh


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['hero', 'icon'])
    ap.add_argument('src'); ap.add_argument('dst')
    ap.add_argument('--glow'); ap.add_argument('--size', type=int, default=256)
    a = ap.parse_args()
    im = Image.open(a.src).convert('RGBA')
    if a.glow:
        im = add_glow(im, a.glow, 10 if a.mode == 'hero' else 5)
    if a.mode == 'hero':
        bb = im.getbbox(); pad = int(max(im.size) * 0.06)
        im = im.crop((max(0, bb[0] - pad), max(0, bb[1] - pad), min(im.width, bb[2] + pad), min(im.height, bb[3] + pad)))
        shadow(im, 18, 22, .8).save(a.dst)
    else:  # auto-fit: crop to content, centre on a square with 7% padding, then shadow + resize
        bb = im.getbbox(); im = im.crop(bb)
        side = int(max(im.size) * 1.14)
        sq = Image.new('RGBA', (side, side), (0, 0, 0, 0))
        sq.alpha_composite(im, ((side - im.width) // 2, (side - im.height) // 2))
        k = side / 512  # keep the shadow proportional to the 512 px design size
        shadow(sq, max(1, int(6 * k)), max(1, int(7 * k)), .75).resize((a.size, a.size), Image.LANCZOS).save(a.dst)
    print('wrote', a.dst)


if __name__ == '__main__':
    main()
