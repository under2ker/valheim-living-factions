#!/usr/bin/env bash
# Build every deliverable for one model (or all): hero render, inventory icon, geometry export.
# Usage: tools/build_all.sh [model|all]   (default: wolf-fang-axe)
set -euo pipefail
cd "$(dirname "$0")/.."
build() {
  local M="$1" T; T="$(mktemp -d)"
  mkdir -p output
  for V in hero icon; do
    node tools/shot.js "model=$M&view=$V" "$T/$V.png" >/dev/null
    node tools/shot.js "model=$M&view=$V&pass=emit" "$T/${V}_glow.png" >/dev/null
  done
  python3 tools/postprocess.py hero "$T/hero.png" "output/${M}.png" --glow "$T/hero_glow.png"
  python3 tools/postprocess.py icon "$T/icon.png" "output/${M}-icon.png" --glow "$T/icon_glow.png" --size 256
  node tools/export.js "$M" "output/export"
  rm -rf "$T"
}
if [ "${1:-}" = "all" ]; then
  for f in models/*.js; do n="$(basename "$f" .js)"; [ "${n#_}" = "$n" ] && build "$n"; done
else
  build "${1:-wolf-fang-axe}"
fi
echo "done -> output/"
