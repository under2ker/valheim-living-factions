#!/usr/bin/env node
// Render one PNG with a transparent background.
// Usage: node tools/shot.js "<hash params>" out.png
//   e.g. node tools/shot.js "model=wolf-fang-axe&view=hero" output/hero_raw.png
const { openRender } = require('./_browser');
(async () => {
  const [, , hash, out] = process.argv;
  if (!hash || !out) { console.error('usage: node tools/shot.js "<hash>" out.png'); process.exit(2); }
  const { browser, page } = await openRender(hash);
  await page.locator('#c').screenshot({ path: out, omitBackground: true });
  await browser.close();
  console.log('wrote', out);
})().catch(e => { console.error(e); process.exit(1); });
